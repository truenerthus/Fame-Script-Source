﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;

namespace ns4
{
	// Token: 0x02000016 RID: 22
	// (Invoke) Token: 0x06000084 RID: 132
	[GeneratedCode("System.Web.Services", "4.0.30319.1")]
	public delegate void GDelegate0(object sender, AsyncCompletedEventArgs e);
}
