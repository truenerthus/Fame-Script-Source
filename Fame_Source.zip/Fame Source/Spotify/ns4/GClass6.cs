﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Web.Services;
using System.Web.Services.Description;
using System.Web.Services.Protocols;
using ns5;

namespace ns4
{
	// Token: 0x02000015 RID: 21
	[GeneratedCode("System.Web.Services", "4.0.30319.1")]
	[WebServiceBinding(Name = "ErrorReportingSoap", Namespace = "http://secureteam.net/webservices/")]
	[DesignerCategory("code")]
	[DebuggerStepThrough]
	public class GClass6 : SoapHttpClientProtocol
	{
		// Token: 0x06000076 RID: 118 RVA: 0x000024C3 File Offset: 0x000006C3
		public GClass6()
		{
			this.String_0 = Class4.Class4_0.String_0;
			if (this.method_5(this.String_0))
			{
				this.Boolean_0 = true;
				this.bool_0 = false;
				return;
			}
			this.bool_0 = true;
		}

		// Token: 0x17000008 RID: 8
		// (get) Token: 0x06000077 RID: 119 RVA: 0x000024FF File Offset: 0x000006FF
		// (set) Token: 0x06000078 RID: 120 RVA: 0x00002507 File Offset: 0x00000707
		public string String_0
		{
			get
			{
				return base.Url;
			}
			set
			{
				if (this.method_5(base.Url) && !this.bool_0 && !this.method_5(value))
				{
					base.UseDefaultCredentials = false;
				}
				base.Url = value;
			}
		}

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x06000079 RID: 121 RVA: 0x00002536 File Offset: 0x00000736
		// (set) Token: 0x0600007A RID: 122 RVA: 0x0000253E File Offset: 0x0000073E
		public bool Boolean_0
		{
			get
			{
				return base.UseDefaultCredentials;
			}
			set
			{
				base.UseDefaultCredentials = value;
				this.bool_0 = true;
			}
		}

		// Token: 0x14000001 RID: 1
		// (add) Token: 0x0600007B RID: 123 RVA: 0x00007CAC File Offset: 0x00005EAC
		// (remove) Token: 0x0600007C RID: 124 RVA: 0x00007CE4 File Offset: 0x00005EE4
		public event GDelegate0 Event_0
		{
			[CompilerGenerated]
			add
			{
				GDelegate0 gdelegate = this.gdelegate0_0;
				GDelegate0 gdelegate2;
				do
				{
					gdelegate2 = gdelegate;
					GDelegate0 value2 = (GDelegate0)Delegate.Combine(gdelegate2, value);
					gdelegate = Interlocked.CompareExchange<GDelegate0>(ref this.gdelegate0_0, value2, gdelegate2);
				}
				while (gdelegate != gdelegate2);
			}
			[CompilerGenerated]
			remove
			{
				GDelegate0 gdelegate = this.gdelegate0_0;
				GDelegate0 gdelegate2;
				do
				{
					gdelegate2 = gdelegate;
					GDelegate0 value2 = (GDelegate0)Delegate.Remove(gdelegate2, value);
					gdelegate = Interlocked.CompareExchange<GDelegate0>(ref this.gdelegate0_0, value2, gdelegate2);
				}
				while (gdelegate != gdelegate2);
			}
		}

		// Token: 0x0600007D RID: 125 RVA: 0x0000254E File Offset: 0x0000074E
		[SoapDocumentMethod("http://secureteam.net/webservices/CreateErrorReport", RequestNamespace = "http://secureteam.net/webservices/", ResponseNamespace = "http://secureteam.net/webservices/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public void method_0(string xml)
		{
			base.Invoke("CreateErrorReport", new object[]
			{
				xml
			});
		}

		// Token: 0x0600007E RID: 126 RVA: 0x00002566 File Offset: 0x00000766
		public void method_1(string xml)
		{
			this.method_2(xml, null);
		}

		// Token: 0x0600007F RID: 127 RVA: 0x00002570 File Offset: 0x00000770
		public void method_2(string xml, object userState)
		{
			if (this.sendOrPostCallback_0 == null)
			{
				this.sendOrPostCallback_0 = new SendOrPostCallback(this.method_3);
			}
			base.InvokeAsync("CreateErrorReport", new object[]
			{
				xml
			}, this.sendOrPostCallback_0, userState);
		}

		// Token: 0x06000080 RID: 128 RVA: 0x00007D1C File Offset: 0x00005F1C
		private void method_3(object arg)
		{
			if (this.gdelegate0_0 != null)
			{
				InvokeCompletedEventArgs invokeCompletedEventArgs = (InvokeCompletedEventArgs)arg;
				this.gdelegate0_0(this, new AsyncCompletedEventArgs(invokeCompletedEventArgs.Error, invokeCompletedEventArgs.Cancelled, invokeCompletedEventArgs.UserState));
			}
		}

		// Token: 0x06000081 RID: 129 RVA: 0x000025A8 File Offset: 0x000007A8
		public void method_4(object userState)
		{
			base.CancelAsync(userState);
		}

		// Token: 0x06000082 RID: 130 RVA: 0x00007D5C File Offset: 0x00005F5C
		private bool method_5(string url)
		{
			if (url != null && !(url == string.Empty))
			{
				Uri uri = new Uri(url);
				return uri.Port >= 1024 && string.Compare(uri.Host, "localHost", StringComparison.OrdinalIgnoreCase) == 0;
			}
			return false;
		}

		// Token: 0x0400008E RID: 142
		private SendOrPostCallback sendOrPostCallback_0;

		// Token: 0x0400008F RID: 143
		private bool bool_0;

		// Token: 0x04000090 RID: 144
		[CompilerGenerated]
		private GDelegate0 gdelegate0_0;
	}
}
