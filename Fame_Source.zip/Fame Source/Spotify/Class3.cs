﻿using System;

// Token: 0x02000013 RID: 19
internal class Class3
{
	// Token: 0x04000088 RID: 136
	public const string string_0 = "AgileDotNet.Console";
}
