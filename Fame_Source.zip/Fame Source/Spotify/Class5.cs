﻿using System;

// Token: 0x02000018 RID: 24
internal class Class5
{
	// Token: 0x04000092 RID: 146
	public const string string_0 = "AgileDotNet.Console";
}
