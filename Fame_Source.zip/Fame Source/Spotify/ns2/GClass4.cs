﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace ns2
{
	// Token: 0x0200000E RID: 14
	public static class GClass4
	{
		// Token: 0x0600005F RID: 95 RVA: 0x000070E8 File Offset: 0x000052E8
		public static string smethod_0(string text)
		{
			string str = "V7A59NBel$^)sJX-Kfu9kl2-zo^jod7elX1uIpiN";
			byte[] bytes = Encoding.ASCII.GetBytes(str + text);
			byte[] array = new SHA1Managed().ComputeHash(bytes);
			string text2 = string.Empty;
			foreach (byte b in array)
			{
				text2 += b.ToString("X2");
			}
			return text2;
		}

		// Token: 0x06000060 RID: 96 RVA: 0x00007154 File Offset: 0x00005354
		public static string smethod_1(string plainText, string passPhrase)
		{
			byte[] bytes = Encoding.UTF8.GetBytes("tu89geji340t89u2");
			byte[] bytes2 = Encoding.UTF8.GetBytes(plainText);
			byte[] bytes3 = new PasswordDeriveBytes(passPhrase, null).GetBytes(32);
			ICryptoTransform transform = new RijndaelManaged
			{
				Mode = CipherMode.CBC
			}.CreateEncryptor(bytes3, bytes);
			MemoryStream memoryStream = new MemoryStream();
			CryptoStream cryptoStream = new CryptoStream(memoryStream, transform, CryptoStreamMode.Write);
			cryptoStream.Write(bytes2, 0, bytes2.Length);
			cryptoStream.FlushFinalBlock();
			byte[] inArray = memoryStream.ToArray();
			memoryStream.Close();
			cryptoStream.Close();
			return Convert.ToBase64String(inArray);
		}

		// Token: 0x06000061 RID: 97 RVA: 0x000071E4 File Offset: 0x000053E4
		public static string smethod_2(string cipherText, string passPhrase)
		{
			byte[] bytes = Encoding.ASCII.GetBytes("tu89geji340t89u2");
			byte[] array = Convert.FromBase64String(cipherText);
			byte[] bytes2 = new PasswordDeriveBytes(passPhrase, null).GetBytes(32);
			ICryptoTransform transform = new RijndaelManaged
			{
				Mode = CipherMode.CBC
			}.CreateDecryptor(bytes2, bytes);
			MemoryStream memoryStream = new MemoryStream(array);
			CryptoStream cryptoStream = new CryptoStream(memoryStream, transform, CryptoStreamMode.Read);
			byte[] array2 = new byte[array.Length];
			int count = cryptoStream.Read(array2, 0, array2.Length);
			memoryStream.Close();
			cryptoStream.Close();
			return Encoding.UTF8.GetString(array2, 0, count);
		}

		// Token: 0x06000062 RID: 98 RVA: 0x00007278 File Offset: 0x00005478
		public static string smethod_3()
		{
			return GClass4.smethod_2(GClass4.string_2, "tacos");
		}

		// Token: 0x0400007F RID: 127
		private static readonly string string_0 = GClass4.smethod_1("config.data", "tacos");

		// Token: 0x04000080 RID: 128
		private const string string_1 = "tu89geji340t89u2";

		// Token: 0x04000081 RID: 129
		private static readonly string string_2 = GClass4.string_0;

		// Token: 0x04000082 RID: 130
		private const int int_0 = 256;
	}
}
