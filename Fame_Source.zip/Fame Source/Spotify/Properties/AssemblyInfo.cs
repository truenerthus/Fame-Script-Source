﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright("Fame - Copyright ©  2020")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("ce5704e6-2ab9-4cca-bd7c-46e3ba8a901e")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyProduct("Fame")]
[assembly: AssemblyTitle("Fame")]
