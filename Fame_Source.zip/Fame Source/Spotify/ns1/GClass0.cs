﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Management;
using System.Security.Cryptography;
using System.Text;

namespace ns1
{
	// Token: 0x02000004 RID: 4
	public static class GClass0
	{
		// Token: 0x06000009 RID: 9 RVA: 0x00002794 File Offset: 0x00000994
		public static string smethod_0()
		{
			string text = GClass0.smethod_13(GClass0.smethod_11());
			string result;
			if (text.Length < 20)
			{
				result = text.Insert(4, "-");
			}
			else
			{
				result = text.Substring(0, 20).Insert(4, "-");
			}
			return result;
		}

		// Token: 0x0600000A RID: 10 RVA: 0x000027E0 File Offset: 0x000009E0
		public static string smethod_1()
		{
			string text = string.Empty;
			foreach (ManagementBaseObject managementBaseObject in new ManagementClass("win32_processor").GetInstances())
			{
				ManagementObject managementObject = (ManagementObject)managementBaseObject;
				if (text == "")
				{
					text = managementObject.Properties["processorID"].Value.ToString();
					break;
				}
			}
			return text;
		}

		// Token: 0x0600000B RID: 11 RVA: 0x0000286C File Offset: 0x00000A6C
		private static string smethod_2(IList<byte> bt)
		{
			string text = string.Empty;
			for (int i = 0; i < bt.Count; i++)
			{
				byte b = bt[i];
				int num = (int)(b & 15);
				int num2 = b >> 4 & 15;
				if (num2 > 9)
				{
					text += ((char)(num2 - 10 + 65)).ToString(CultureInfo.InvariantCulture);
				}
				else
				{
					text += num2.ToString(CultureInfo.InvariantCulture);
				}
				if (num > 9)
				{
					text += ((char)(num - 10 + 65)).ToString(CultureInfo.InvariantCulture);
				}
				else
				{
					text += num.ToString(CultureInfo.InvariantCulture);
				}
				if (i + 1 != bt.Count && (i + 1) % 2 == 0)
				{
					text += "-";
				}
			}
			return text;
		}

		// Token: 0x0600000C RID: 12 RVA: 0x0000293C File Offset: 0x00000B3C
		private static string smethod_3(string wmiClass, string wmiProperty, string wmiMustBeTrue)
		{
			string text = "";
			foreach (ManagementBaseObject managementBaseObject in new ManagementClass(wmiClass).GetInstances())
			{
				if (!(managementBaseObject[wmiMustBeTrue].ToString() != "True") && !(text != ""))
				{
					try
					{
						text = managementBaseObject[wmiProperty].ToString();
						break;
					}
					catch
					{
					}
				}
			}
			return text;
		}

		// Token: 0x0600000D RID: 13 RVA: 0x000029D8 File Offset: 0x00000BD8
		private static string smethod_4(string wmiClass, string wmiProperty)
		{
			string text = "";
			foreach (ManagementBaseObject managementBaseObject in new ManagementClass(wmiClass).GetInstances())
			{
				if (!(text != ""))
				{
					try
					{
						text = managementBaseObject[wmiProperty].ToString();
						break;
					}
					catch
					{
					}
				}
			}
			return text;
		}

		// Token: 0x0600000E RID: 14 RVA: 0x00002A5C File Offset: 0x00000C5C
		private static string smethod_5()
		{
			string text = GClass0.smethod_4("Win32_Processor", "UniqueId");
			string result;
			if (text != "")
			{
				result = text;
			}
			else
			{
				text = GClass0.smethod_4("Win32_Processor", "ProcessorId");
				if (text != "")
				{
					result = text;
				}
				else
				{
					text = GClass0.smethod_4("Win32_Processor", "Name");
					if (text == "")
					{
						text = GClass0.smethod_4("Win32_Processor", "Manufacturer");
					}
					text += GClass0.smethod_4("Win32_Processor", "MaxClockSpeed");
					result = text;
				}
			}
			return result;
		}

		// Token: 0x0600000F RID: 15 RVA: 0x00002AF4 File Offset: 0x00000CF4
		private static string smethod_6()
		{
			return string.Concat(new string[]
			{
				GClass0.smethod_4("Win32_BIOS", "Manufacturer"),
				GClass0.smethod_4("Win32_BIOS", "SMBIOSBIOSVersion"),
				GClass0.smethod_4("Win32_BIOS", "IdentificationCode"),
				GClass0.smethod_4("Win32_BIOS", "SerialNumber"),
				GClass0.smethod_4("Win32_BIOS", "ReleaseDate"),
				GClass0.smethod_4("Win32_BIOS", "Version")
			});
		}

		// Token: 0x06000010 RID: 16 RVA: 0x00002B7C File Offset: 0x00000D7C
		private static string smethod_7()
		{
			return GClass0.smethod_4("Win32_DiskDrive", "Model") + GClass0.smethod_4("Win32_DiskDrive", "Manufacturer") + GClass0.smethod_4("Win32_DiskDrive", "Signature") + GClass0.smethod_4("Win32_DiskDrive", "TotalHeads");
		}

		// Token: 0x06000011 RID: 17 RVA: 0x00002BD0 File Offset: 0x00000DD0
		private static string smethod_8()
		{
			return GClass0.smethod_4("Win32_BaseBoard", "Model") + GClass0.smethod_4("Win32_BaseBoard", "Manufacturer") + GClass0.smethod_4("Win32_BaseBoard", "Name") + GClass0.smethod_4("Win32_BaseBoard", "SerialNumber");
		}

		// Token: 0x06000012 RID: 18 RVA: 0x00002C24 File Offset: 0x00000E24
		private static string smethod_9()
		{
			return GClass0.smethod_4("Win32_VideoController", "DriverVersion") + GClass0.smethod_4("Win32_VideoController", "Name");
		}

		// Token: 0x06000013 RID: 19 RVA: 0x00002C58 File Offset: 0x00000E58
		private static string smethod_10()
		{
			return GClass0.smethod_3("Win32_NetworkAdapterConfiguration", "MACAddress", "IPEnabled");
		}

		// Token: 0x06000014 RID: 20 RVA: 0x00002C80 File Offset: 0x00000E80
		private static string smethod_11()
		{
			if (string.IsNullOrEmpty(GClass0.string_0))
			{
				GClass0.string_0 = GClass0.smethod_12(string.Concat(new string[]
				{
					"CPU >> ",
					GClass0.smethod_5(),
					"\nBIOS >> ",
					GClass0.smethod_6(),
					"\nBASE >> ",
					GClass0.smethod_8(),
					"\nDISK >> ",
					GClass0.smethod_7(),
					"\nVIDEO >> ",
					GClass0.smethod_9(),
					"\nMAC >> ",
					GClass0.smethod_10()
				}));
			}
			return GClass0.string_0;
		}

		// Token: 0x06000015 RID: 21 RVA: 0x00002D1C File Offset: 0x00000F1C
		private static string smethod_12(string s)
		{
			HashAlgorithm hashAlgorithm = new MD5CryptoServiceProvider();
			byte[] bytes = Encoding.ASCII.GetBytes(s);
			return GClass0.smethod_2(hashAlgorithm.ComputeHash(bytes));
		}

		// Token: 0x06000016 RID: 22 RVA: 0x00002D4C File Offset: 0x00000F4C
		private static string smethod_13(string rawData)
		{
			string result;
			using (SHA256 sha = SHA256.Create())
			{
				byte[] array = sha.ComputeHash(Encoding.UTF8.GetBytes(rawData));
				StringBuilder stringBuilder = new StringBuilder();
				for (int i = 0; i < array.Length; i++)
				{
					stringBuilder.Append(array[i].ToString("X2"));
				}
				result = stringBuilder.ToString();
			}
			return result;
		}

		// Token: 0x04000004 RID: 4
		private static string string_0 = string.Empty;
	}
}
