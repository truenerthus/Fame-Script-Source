﻿namespace ns1
{
	// Token: 0x0200000B RID: 11
	public partial class Setting : global::System.Windows.Forms.Form
	{
		// Token: 0x06000057 RID: 87 RVA: 0x000044AC File Offset: 0x000026AC
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.icontainer_0 != null)
			{
				this.icontainer_0.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000058 RID: 88 RVA: 0x000044D8 File Offset: 0x000026D8
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Setting));
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.metroCheckBox3 = new MetroFramework.Controls.MetroCheckBox();
            this.metroCheckBox2 = new MetroFramework.Controls.MetroCheckBox();
            this.metroCheckBox1 = new MetroFramework.Controls.MetroCheckBox();
            this.metroPanel2 = new MetroFramework.Controls.MetroPanel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroComboBox3 = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroComboBox2 = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroTrackBar3 = new MetroFramework.Controls.MetroTrackBar();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroComboBox1 = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroTrackBar1 = new MetroFramework.Controls.MetroTrackBar();
            this.metroTrackBar2 = new MetroFramework.Controls.MetroTrackBar();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.HotKeysLabel = new System.Windows.Forms.Label();
            this.WeaponLabel = new System.Windows.Forms.Label();
            this.WeaponSelectCombo = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.ToggleButton = new System.Windows.Forms.Button();
            this.VersionLabel = new System.Windows.Forms.Label();
            this.ExitButton = new System.Windows.Forms.Button();
            this.MinButton = new System.Windows.Forms.Button();
            this.TitleLabel = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.linkbuynow = new System.Windows.Forms.LinkLabel();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.label12 = new System.Windows.Forms.Label();
            this.cmbScope = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.cmbAttach = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.trackBar_Min = new System.Windows.Forms.TrackBar();
            this.trackBar_Max = new System.Windows.Forms.TrackBar();
            this.numericUpDown_sens = new System.Windows.Forms.NumericUpDown();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.metroPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_Min)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_Max)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_sens)).BeginInit();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.metroPanel1.Controls.Add(this.metroLabel9);
            this.metroPanel1.Controls.Add(this.numericUpDown2);
            this.metroPanel1.Controls.Add(this.metroLabel8);
            this.metroPanel1.Controls.Add(this.numericUpDown1);
            this.metroPanel1.Controls.Add(this.metroCheckBox3);
            this.metroPanel1.Controls.Add(this.metroCheckBox2);
            this.metroPanel1.Controls.Add(this.metroCheckBox1);
            this.metroPanel1.Controls.Add(this.metroPanel2);
            this.metroPanel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(266, 570);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(125, 10);
            this.metroPanel1.Style = MetroFramework.MetroColorStyle.Red;
            this.metroPanel1.TabIndex = 1;
            this.metroPanel1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel1.UseCustomBackColor = true;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            this.metroPanel1.Visible = false;
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.Location = new System.Drawing.Point(4, 144);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(86, 19);
            this.metroLabel9.TabIndex = 15;
            this.metroLabel9.Text = "Ingame FOV:";
            this.metroLabel9.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroLabel9.UseCustomBackColor = true;
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.numericUpDown2.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.numericUpDown2.Location = new System.Drawing.Point(4, 166);
            this.numericUpDown2.Minimum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(88, 20);
            this.numericUpDown2.TabIndex = 14;
            this.numericUpDown2.Value = new decimal(new int[] {
            60,
            0,
            0,
            0});
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(4, 189);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(93, 19);
            this.metroLabel8.TabIndex = 13;
            this.metroLabel8.Text = "Ingame Sense:";
            this.metroLabel8.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroLabel8.UseCustomBackColor = true;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.numericUpDown1.DecimalPlaces = 2;
            this.numericUpDown1.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.numericUpDown1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown1.Location = new System.Drawing.Point(4, 211);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            65536});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(88, 20);
            this.numericUpDown1.TabIndex = 7;
            this.numericUpDown1.Value = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            // 
            // metroCheckBox3
            // 
            this.metroCheckBox3.AutoSize = true;
            this.metroCheckBox3.Location = new System.Drawing.Point(4, 126);
            this.metroCheckBox3.Name = "metroCheckBox3";
            this.metroCheckBox3.Size = new System.Drawing.Size(99, 15);
            this.metroCheckBox3.TabIndex = 6;
            this.metroCheckBox3.Text = "Better Smooth";
            this.metroCheckBox3.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroCheckBox3.UseCustomBackColor = true;
            this.metroCheckBox3.UseSelectable = true;
            // 
            // metroCheckBox2
            // 
            this.metroCheckBox2.AutoSize = true;
            this.metroCheckBox2.Location = new System.Drawing.Point(4, 105);
            this.metroCheckBox2.Name = "metroCheckBox2";
            this.metroCheckBox2.Size = new System.Drawing.Size(70, 15);
            this.metroCheckBox2.TabIndex = 3;
            this.metroCheckBox2.Text = "Min Max";
            this.metroCheckBox2.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroCheckBox2.UseCustomBackColor = true;
            this.metroCheckBox2.UseSelectable = true;
            // 
            // metroCheckBox1
            // 
            this.metroCheckBox1.AutoSize = true;
            this.metroCheckBox1.FontWeight = MetroFramework.MetroCheckBoxWeight.Bold;
            this.metroCheckBox1.Location = new System.Drawing.Point(4, 83);
            this.metroCheckBox1.Name = "metroCheckBox1";
            this.metroCheckBox1.Size = new System.Drawing.Size(70, 15);
            this.metroCheckBox1.TabIndex = 2;
            this.metroCheckBox1.Text = "Activate";
            this.metroCheckBox1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroCheckBox1.UseCustomBackColor = true;
            this.metroCheckBox1.UseSelectable = true;
            // 
            // metroPanel2
            // 
            this.metroPanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.metroPanel2.Controls.Add(this.metroLabel6);
            this.metroPanel2.Controls.Add(this.metroComboBox3);
            this.metroPanel2.Controls.Add(this.metroLabel5);
            this.metroPanel2.Controls.Add(this.metroComboBox2);
            this.metroPanel2.Controls.Add(this.metroLabel4);
            this.metroPanel2.Controls.Add(this.metroTrackBar3);
            this.metroPanel2.Controls.Add(this.metroLabel3);
            this.metroPanel2.Controls.Add(this.metroComboBox1);
            this.metroPanel2.Controls.Add(this.metroLabel2);
            this.metroPanel2.Controls.Add(this.metroLabel1);
            this.metroPanel2.Controls.Add(this.metroTrackBar1);
            this.metroPanel2.Controls.Add(this.metroTrackBar2);
            this.metroPanel2.HorizontalScrollbarBarColor = true;
            this.metroPanel2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel2.HorizontalScrollbarSize = 10;
            this.metroPanel2.Location = new System.Drawing.Point(45, 0);
            this.metroPanel2.Name = "metroPanel2";
            this.metroPanel2.Size = new System.Drawing.Size(346, 15);
            this.metroPanel2.TabIndex = 2;
            this.metroPanel2.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroPanel2.UseCustomBackColor = true;
            this.metroPanel2.VerticalScrollbarBarColor = true;
            this.metroPanel2.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel2.VerticalScrollbarSize = 10;
            this.metroPanel2.Visible = false;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(212, 189);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(45, 19);
            this.metroLabel6.TabIndex = 14;
            this.metroLabel6.Text = "Scope";
            this.metroLabel6.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroLabel6.UseCustomBackColor = true;
            // 
            // metroComboBox3
            // 
            this.metroComboBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.metroComboBox3.FormattingEnabled = true;
            this.metroComboBox3.ItemHeight = 23;
            this.metroComboBox3.Items.AddRange(new object[] {
            "Simple Handmade Sight",
            "Holosight",
            "8x Zoom Scope",
            "16x Zoom Scope",
            "None"});
            this.metroComboBox3.Location = new System.Drawing.Point(13, 189);
            this.metroComboBox3.Name = "metroComboBox3";
            this.metroComboBox3.Size = new System.Drawing.Size(197, 29);
            this.metroComboBox3.TabIndex = 13;
            this.metroComboBox3.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroComboBox3.UseCustomBackColor = true;
            this.metroComboBox3.UseSelectable = true;
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(212, 144);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(76, 19);
            this.metroLabel5.TabIndex = 12;
            this.metroLabel5.Text = "Attachment";
            this.metroLabel5.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroLabel5.UseCustomBackColor = true;
            // 
            // metroComboBox2
            // 
            this.metroComboBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.metroComboBox2.FormattingEnabled = true;
            this.metroComboBox2.ItemHeight = 23;
            this.metroComboBox2.Items.AddRange(new object[] {
            "Muzzle Boost",
            "Muzzle Brake",
            "Silencer",
            "None"});
            this.metroComboBox2.Location = new System.Drawing.Point(13, 144);
            this.metroComboBox2.Name = "metroComboBox2";
            this.metroComboBox2.Size = new System.Drawing.Size(197, 29);
            this.metroComboBox2.TabIndex = 11;
            this.metroComboBox2.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroComboBox2.UseCustomBackColor = true;
            this.metroComboBox2.UseSelectable = true;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(219, 113);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(55, 19);
            this.metroLabel4.TabIndex = 10;
            this.metroLabel4.Text = "Smooth";
            this.metroLabel4.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroLabel4.UseCustomBackColor = true;
            // 
            // metroTrackBar3
            // 
            this.metroTrackBar3.BackColor = System.Drawing.Color.Transparent;
            this.metroTrackBar3.LargeChange = 1;
            this.metroTrackBar3.Location = new System.Drawing.Point(13, 113);
            this.metroTrackBar3.Maximum = 10;
            this.metroTrackBar3.Minimum = 1;
            this.metroTrackBar3.Name = "metroTrackBar3";
            this.metroTrackBar3.Size = new System.Drawing.Size(200, 25);
            this.metroTrackBar3.TabIndex = 9;
            this.metroTrackBar3.Text = "metroTrackBar3";
            this.metroTrackBar3.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTrackBar3.UseCustomBackColor = true;
            this.metroTrackBar3.Value = 1;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(212, 69);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(58, 19);
            this.metroLabel3.TabIndex = 8;
            this.metroLabel3.Text = "Weapon";
            this.metroLabel3.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroLabel3.UseCustomBackColor = true;
            // 
            // metroComboBox1
            // 
            this.metroComboBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.metroComboBox1.FormattingEnabled = true;
            this.metroComboBox1.ItemHeight = 23;
            this.metroComboBox1.Items.AddRange(new object[] {
            "Assault Rifle",
            "LR-300 Assault Rifle",
            "M249",
            "Custom SMG",
            "MP5A4",
            "Thompson",
            "None"});
            this.metroComboBox1.Location = new System.Drawing.Point(13, 69);
            this.metroComboBox1.Name = "metroComboBox1";
            this.metroComboBox1.Size = new System.Drawing.Size(197, 29);
            this.metroComboBox1.TabIndex = 7;
            this.metroComboBox1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroComboBox1.UseCustomBackColor = true;
            this.metroComboBox1.UseSelectable = true;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(219, 37);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(45, 19);
            this.metroLabel2.TabIndex = 6;
            this.metroLabel2.Text = "Max%";
            this.metroLabel2.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroLabel2.UseCustomBackColor = true;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(219, 6);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(42, 19);
            this.metroLabel1.TabIndex = 5;
            this.metroLabel1.Text = "Min%";
            this.metroLabel1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroLabel1.UseCustomBackColor = true;
            // 
            // metroTrackBar1
            // 
            this.metroTrackBar1.BackColor = System.Drawing.Color.Transparent;
            this.metroTrackBar1.LargeChange = 1;
            this.metroTrackBar1.Location = new System.Drawing.Point(13, 21);
            this.metroTrackBar1.Maximum = 99;
            this.metroTrackBar1.Name = "metroTrackBar1";
            this.metroTrackBar1.Size = new System.Drawing.Size(292, 10);
            this.metroTrackBar1.TabIndex = 4;
            this.metroTrackBar1.Text = "metroTrackBar1";
            this.metroTrackBar1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTrackBar1.UseCustomBackColor = true;
            this.metroTrackBar1.Value = 0;
            // 
            // metroTrackBar2
            // 
            this.metroTrackBar2.BackColor = System.Drawing.Color.Transparent;
            this.metroTrackBar2.LargeChange = 1;
            this.metroTrackBar2.Location = new System.Drawing.Point(13, 37);
            this.metroTrackBar2.Minimum = 1;
            this.metroTrackBar2.Name = "metroTrackBar2";
            this.metroTrackBar2.Size = new System.Drawing.Size(200, 25);
            this.metroTrackBar2.TabIndex = 3;
            this.metroTrackBar2.Text = "metroTrackBar2";
            this.metroTrackBar2.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTrackBar2.UseCustomBackColor = true;
            this.metroTrackBar2.Value = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(56, 590);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(128, 13);
            this.label6.TabIndex = 27;
            this.label6.Text = "NUMPAD6: Custom SMG";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(56, 572);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 13);
            this.label5.TabIndex = 26;
            this.label5.Text = "NUMPAD5: MP5";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(56, 555);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(110, 13);
            this.label4.TabIndex = 25;
            this.label4.Text = "NUMPAD4: Thomson";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(56, 524);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 13);
            this.label2.TabIndex = 24;
            this.label2.Text = "NUMPAD2: LR-300";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(56, 506);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 13);
            this.label1.TabIndex = 23;
            this.label1.Text = "NUMPAD1: Assault Rifle";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(56, 539);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 13);
            this.label3.TabIndex = 28;
            this.label3.Text = "NUMPAD3: M249";
            // 
            // HotKeysLabel
            // 
            this.HotKeysLabel.AutoSize = true;
            this.HotKeysLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HotKeysLabel.ForeColor = System.Drawing.SystemColors.Highlight;
            this.HotKeysLabel.Location = new System.Drawing.Point(55, 532);
            this.HotKeysLabel.Name = "HotKeysLabel";
            this.HotKeysLabel.Size = new System.Drawing.Size(224, 20);
            this.HotKeysLabel.TabIndex = 29;
            this.HotKeysLabel.Text = "HotKeys (Insert To Toggle)";
            // 
            // WeaponLabel
            // 
            this.WeaponLabel.AutoSize = true;
            this.WeaponLabel.BackColor = System.Drawing.Color.Transparent;
            this.WeaponLabel.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WeaponLabel.ForeColor = System.Drawing.SystemColors.Highlight;
            this.WeaponLabel.Location = new System.Drawing.Point(44, 134);
            this.WeaponLabel.Name = "WeaponLabel";
            this.WeaponLabel.Size = new System.Drawing.Size(156, 19);
            this.WeaponLabel.TabIndex = 30;
            this.WeaponLabel.Text = "Selected Weapon:";
            // 
            // WeaponSelectCombo
            // 
            this.WeaponSelectCombo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.WeaponSelectCombo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.WeaponSelectCombo.ForeColor = System.Drawing.Color.White;
            this.WeaponSelectCombo.FormattingEnabled = true;
            this.WeaponSelectCombo.Items.AddRange(new object[] {
            "(#NUM1)Assault Rifle",
            "(#NUM2)LR-300",
            "(#NUM3)M249",
            "(#NUM4)Thompson",
            "(#NUM5)MP5A4",
            "(#NUM6)Custom SMG"});
            this.WeaponSelectCombo.Location = new System.Drawing.Point(224, 132);
            this.WeaponSelectCombo.Name = "WeaponSelectCombo";
            this.WeaponSelectCombo.Size = new System.Drawing.Size(300, 21);
            this.WeaponSelectCombo.TabIndex = 31;
            this.WeaponSelectCombo.SelectedIndexChanged += new System.EventHandler(this.WeaponSelectCombo_SelectedIndexChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(388, 539);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(85, 44);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 33;
            this.pictureBox1.TabStop = false;
            // 
            // ToggleButton
            // 
            this.ToggleButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.ToggleButton.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.ToggleButton.FlatAppearance.BorderSize = 3;
            this.ToggleButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ToggleButton.ForeColor = System.Drawing.Color.White;
            this.ToggleButton.Location = new System.Drawing.Point(82, 65);
            this.ToggleButton.Name = "ToggleButton";
            this.ToggleButton.Size = new System.Drawing.Size(450, 41);
            this.ToggleButton.TabIndex = 34;
            this.ToggleButton.Text = "Disabled(NUMPAD7)";
            this.ToggleButton.UseVisualStyleBackColor = false;
            this.ToggleButton.Click += new System.EventHandler(this.ToggleButton_Click);
            // 
            // VersionLabel
            // 
            this.VersionLabel.AutoSize = true;
            this.VersionLabel.BackColor = System.Drawing.Color.Transparent;
            this.VersionLabel.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VersionLabel.ForeColor = System.Drawing.SystemColors.Highlight;
            this.VersionLabel.Location = new System.Drawing.Point(455, 428);
            this.VersionLabel.Name = "VersionLabel";
            this.VersionLabel.Size = new System.Drawing.Size(103, 23);
            this.VersionLabel.TabIndex = 35;
            this.VersionLabel.Text = "Version 2.2";
            // 
            // ExitButton
            // 
            this.ExitButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.ExitButton.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.ExitButton.FlatAppearance.BorderSize = 3;
            this.ExitButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ExitButton.ForeColor = System.Drawing.Color.White;
            this.ExitButton.Location = new System.Drawing.Point(542, 5);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(32, 29);
            this.ExitButton.TabIndex = 36;
            this.ExitButton.Text = "X";
            this.ExitButton.UseVisualStyleBackColor = false;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // MinButton
            // 
            this.MinButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.MinButton.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.MinButton.FlatAppearance.BorderSize = 3;
            this.MinButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MinButton.ForeColor = System.Drawing.Color.White;
            this.MinButton.Location = new System.Drawing.Point(505, 5);
            this.MinButton.Name = "MinButton";
            this.MinButton.Size = new System.Drawing.Size(32, 29);
            this.MinButton.TabIndex = 37;
            this.MinButton.Text = "__";
            this.MinButton.UseVisualStyleBackColor = false;
            this.MinButton.Click += new System.EventHandler(this.MinButton_Click);
            // 
            // TitleLabel
            // 
            this.TitleLabel.AutoSize = true;
            this.TitleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TitleLabel.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.TitleLabel.Location = new System.Drawing.Point(285, 535);
            this.TitleLabel.Name = "TitleLabel";
            this.TitleLabel.Size = new System.Drawing.Size(312, 42);
            this.TitleLabel.TabIndex = 38;
            this.TitleLabel.Text = "FAME Anti-Recoil";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label7.Location = new System.Drawing.Point(242, 436);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(127, 13);
            this.label7.TabIndex = 39;
            this.label7.Text = "Contact me: Fame#7614";
            // 
            // linkbuynow
            // 
            this.linkbuynow.AutoSize = true;
            this.linkbuynow.BackColor = System.Drawing.Color.Transparent;
            this.linkbuynow.LinkColor = System.Drawing.Color.DodgerBlue;
            this.linkbuynow.Location = new System.Drawing.Point(113, 436);
            this.linkbuynow.Name = "linkbuynow";
            this.linkbuynow.Size = new System.Drawing.Size(46, 13);
            this.linkbuynow.TabIndex = 40;
            this.linkbuynow.TabStop = true;
            this.linkbuynow.Text = "Website";
            this.linkbuynow.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkbuynow_LinkClicked);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.label8.Location = new System.Drawing.Point(152, 222);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(87, 16);
            this.label8.TabIndex = 41;
            this.label8.Text = "SENSITIVITY:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label9.Location = new System.Drawing.Point(60, 222);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 16);
            this.label9.TabIndex = 42;
            this.label9.Text = "FOV to 90";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label10.Location = new System.Drawing.Point(44, 178);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(81, 20);
            this.label10.TabIndex = 43;
            this.label10.Text = "Settings:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label11.Location = new System.Drawing.Point(59, 260);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(120, 16);
            this.label11.TabIndex = 44;
            this.label11.Text = "Smoothness Slider:";
            // 
            // trackBar1
            // 
            this.trackBar1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(38)))), ((int)(((byte)(38)))));
            this.trackBar1.LargeChange = 1;
            this.trackBar1.Location = new System.Drawing.Point(138, 288);
            this.trackBar1.Minimum = 1;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(170, 45);
            this.trackBar1.TabIndex = 45;
            this.trackBar1.Value = 1;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label12.Location = new System.Drawing.Point(63, 352);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(48, 16);
            this.label12.TabIndex = 46;
            this.label12.Text = "Scope:";
            // 
            // cmbScope
            // 
            this.cmbScope.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.cmbScope.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbScope.ForeColor = System.Drawing.Color.White;
            this.cmbScope.FormattingEnabled = true;
            this.cmbScope.Items.AddRange(new object[] {
            "Simple Handmade Sight",
            "Holosight",
            "8x Zoom Scope",
            "16x Zoom Scope",
            "None"});
            this.cmbScope.Location = new System.Drawing.Point(138, 351);
            this.cmbScope.Name = "cmbScope";
            this.cmbScope.Size = new System.Drawing.Size(163, 21);
            this.cmbScope.TabIndex = 47;
            this.cmbScope.SelectedIndexChanged += new System.EventHandler(this.cmbScope_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label13.Location = new System.Drawing.Point(334, 352);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(78, 16);
            this.label13.TabIndex = 48;
            this.label13.Text = "Attachment:";
            // 
            // cmbAttach
            // 
            this.cmbAttach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.cmbAttach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbAttach.ForeColor = System.Drawing.Color.White;
            this.cmbAttach.FormattingEnabled = true;
            this.cmbAttach.Items.AddRange(new object[] {
            "Muzzle Boost",
            "Muzzle Brake",
            "Silencer",
            "None"});
            this.cmbAttach.Location = new System.Drawing.Point(418, 351);
            this.cmbAttach.Name = "cmbAttach";
            this.cmbAttach.Size = new System.Drawing.Size(163, 21);
            this.cmbAttach.TabIndex = 49;
            this.cmbAttach.SelectedIndexChanged += new System.EventHandler(this.cmbAttach_SelectedIndexChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label14.Location = new System.Drawing.Point(338, 255);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(45, 16);
            this.label14.TabIndex = 50;
            this.label14.Text = "Min%:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label15.Location = new System.Drawing.Point(338, 301);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(48, 16);
            this.label15.TabIndex = 51;
            this.label15.Text = "Max%:";
            // 
            // trackBar_Min
            // 
            this.trackBar_Min.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.trackBar_Min.Location = new System.Drawing.Point(415, 253);
            this.trackBar_Min.Maximum = 99;
            this.trackBar_Min.Name = "trackBar_Min";
            this.trackBar_Min.Size = new System.Drawing.Size(170, 45);
            this.trackBar_Min.TabIndex = 52;
            this.trackBar_Min.Value = 1;
            this.trackBar_Min.Scroll += new System.EventHandler(this.trackBar_Min_Scroll);
            // 
            // trackBar_Max
            // 
            this.trackBar_Max.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.trackBar_Max.Location = new System.Drawing.Point(415, 300);
            this.trackBar_Max.Maximum = 100;
            this.trackBar_Max.Minimum = 1;
            this.trackBar_Max.Name = "trackBar_Max";
            this.trackBar_Max.Size = new System.Drawing.Size(170, 45);
            this.trackBar_Max.TabIndex = 53;
            this.trackBar_Max.Value = 1;
            this.trackBar_Max.Scroll += new System.EventHandler(this.trackBar_Max_Scroll);
            // 
            // numericUpDown_sens
            // 
            this.numericUpDown_sens.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.numericUpDown_sens.DecimalPlaces = 2;
            this.numericUpDown_sens.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown_sens.Location = new System.Drawing.Point(248, 222);
            this.numericUpDown_sens.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            131072});
            this.numericUpDown_sens.Name = "numericUpDown_sens";
            this.numericUpDown_sens.Size = new System.Drawing.Size(53, 20);
            this.numericUpDown_sens.TabIndex = 55;
            this.numericUpDown_sens.Value = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.numericUpDown_sens.ValueChanged += new System.EventHandler(this.numericUpDown_sens_ValueChanged);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.BackColor = System.Drawing.Color.Transparent;
            this.checkBox1.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.checkBox1.Location = new System.Drawing.Point(341, 221);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(105, 17);
            this.checkBox1.TabIndex = 56;
            this.checkBox1.Text = "MinMax Activate";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // Setting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.BackgroundImage = global::Spotify.Properties.Resources.lol;
            this.ClientSize = new System.Drawing.Size(619, 471);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.numericUpDown_sens);
            this.Controls.Add(this.trackBar_Max);
            this.Controls.Add(this.trackBar_Min);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.cmbAttach);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.cmbScope);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.trackBar1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.linkbuynow);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.TitleLabel);
            this.Controls.Add(this.MinButton);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.VersionLabel);
            this.Controls.Add(this.ToggleButton);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.WeaponSelectCombo);
            this.Controls.Add(this.WeaponLabel);
            this.Controls.Add(this.HotKeysLabel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.metroPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(619, 471);
            this.MinimumSize = new System.Drawing.Size(619, 471);
            this.Name = "Setting";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Setting";
            this.TopMost = true;
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.metroPanel2.ResumeLayout(false);
            this.metroPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_Min)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_Max)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_sens)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		// Token: 0x04000035 RID: 53
		private global::System.ComponentModel.IContainer icontainer_0;

		// Token: 0x04000036 RID: 54
		private global::MetroFramework.Controls.MetroPanel metroPanel1;

		// Token: 0x04000037 RID: 55
		private global::MetroFramework.Controls.MetroLabel metroLabel9;

		// Token: 0x04000038 RID: 56
		private global::System.Windows.Forms.NumericUpDown numericUpDown2;

		// Token: 0x04000039 RID: 57
		private global::MetroFramework.Controls.MetroLabel metroLabel8;

		// Token: 0x0400003A RID: 58
		private global::System.Windows.Forms.NumericUpDown numericUpDown1;

		// Token: 0x0400003B RID: 59
		private global::MetroFramework.Controls.MetroCheckBox metroCheckBox3;

		// Token: 0x0400003C RID: 60
		private global::MetroFramework.Controls.MetroCheckBox metroCheckBox2;

		// Token: 0x0400003D RID: 61
		private global::MetroFramework.Controls.MetroCheckBox metroCheckBox1;

		// Token: 0x0400003E RID: 62
		private global::MetroFramework.Controls.MetroPanel metroPanel2;

		// Token: 0x0400003F RID: 63
		private global::MetroFramework.Controls.MetroLabel metroLabel6;

		// Token: 0x04000040 RID: 64
		private global::MetroFramework.Controls.MetroComboBox metroComboBox3;

		// Token: 0x04000041 RID: 65
		private global::MetroFramework.Controls.MetroLabel metroLabel5;

		// Token: 0x04000042 RID: 66
		private global::MetroFramework.Controls.MetroComboBox metroComboBox2;

		// Token: 0x04000043 RID: 67
		private global::MetroFramework.Controls.MetroLabel metroLabel4;

		// Token: 0x04000044 RID: 68
		private global::MetroFramework.Controls.MetroTrackBar metroTrackBar3;

		// Token: 0x04000045 RID: 69
		private global::MetroFramework.Controls.MetroLabel metroLabel3;

		// Token: 0x04000046 RID: 70
		private global::MetroFramework.Controls.MetroComboBox metroComboBox1;

		// Token: 0x04000047 RID: 71
		private global::MetroFramework.Controls.MetroLabel metroLabel2;

		// Token: 0x04000048 RID: 72
		private global::MetroFramework.Controls.MetroLabel metroLabel1;

		// Token: 0x04000049 RID: 73
		private global::MetroFramework.Controls.MetroTrackBar metroTrackBar1;

		// Token: 0x0400004A RID: 74
		private global::MetroFramework.Controls.MetroTrackBar metroTrackBar2;

		// Token: 0x0400004B RID: 75
		private global::System.Windows.Forms.Label label6;

		// Token: 0x0400004C RID: 76
		private global::System.Windows.Forms.Label label5;

		// Token: 0x0400004D RID: 77
		private global::System.Windows.Forms.Label label4;

		// Token: 0x0400004E RID: 78
		private global::System.Windows.Forms.Label label2;

		// Token: 0x0400004F RID: 79
		private global::System.Windows.Forms.Label label1;

		// Token: 0x04000050 RID: 80
		private global::System.Windows.Forms.Label label3;

		// Token: 0x04000051 RID: 81
		private global::System.Windows.Forms.Label HotKeysLabel;

		// Token: 0x04000052 RID: 82
		private global::System.Windows.Forms.Label WeaponLabel;

		// Token: 0x04000053 RID: 83
		private global::System.Windows.Forms.ComboBox WeaponSelectCombo;

		// Token: 0x04000054 RID: 84
		private global::System.Windows.Forms.PictureBox pictureBox1;

		// Token: 0x04000055 RID: 85
		private global::System.Windows.Forms.Button ToggleButton;

		// Token: 0x04000056 RID: 86
		private global::System.Windows.Forms.Label VersionLabel;

		// Token: 0x04000057 RID: 87
		private global::System.Windows.Forms.Button ExitButton;

		// Token: 0x04000058 RID: 88
		private global::System.Windows.Forms.Button MinButton;

		// Token: 0x04000059 RID: 89
		private global::System.Windows.Forms.Label TitleLabel;

		// Token: 0x0400005A RID: 90
		private global::System.Windows.Forms.Label label7;

		// Token: 0x0400005B RID: 91
		private global::System.Windows.Forms.LinkLabel linkbuynow;

		// Token: 0x0400005C RID: 92
		private global::System.Windows.Forms.Label label8;

		// Token: 0x0400005D RID: 93
		private global::System.Windows.Forms.Label label9;

		// Token: 0x0400005E RID: 94
		private global::System.Windows.Forms.Label label10;

		// Token: 0x0400005F RID: 95
		private global::System.Windows.Forms.Label label11;

		// Token: 0x04000060 RID: 96
		private global::System.Windows.Forms.TrackBar trackBar1;

		// Token: 0x04000061 RID: 97
		private global::System.Windows.Forms.Label label12;

		// Token: 0x04000062 RID: 98
		private global::System.Windows.Forms.ComboBox cmbScope;

		// Token: 0x04000063 RID: 99
		private global::System.Windows.Forms.Label label13;

		// Token: 0x04000064 RID: 100
		private global::System.Windows.Forms.ComboBox cmbAttach;

		// Token: 0x04000065 RID: 101
		private global::System.Windows.Forms.Label label14;

		// Token: 0x04000066 RID: 102
		private global::System.Windows.Forms.Label label15;

		// Token: 0x04000067 RID: 103
		private global::System.Windows.Forms.TrackBar trackBar_Min;

		// Token: 0x04000068 RID: 104
		private global::System.Windows.Forms.TrackBar trackBar_Max;

		// Token: 0x04000069 RID: 105
		private global::System.Windows.Forms.NumericUpDown numericUpDown_sens;

		// Token: 0x0400006A RID: 106
		private global::System.Windows.Forms.CheckBox checkBox1;
	}
}
