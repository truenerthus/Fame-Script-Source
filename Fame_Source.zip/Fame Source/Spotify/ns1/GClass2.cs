﻿using System;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace ns1
{
	// Token: 0x02000009 RID: 9
	public static class GClass2
	{
		// Token: 0x0600002E RID: 46
		[DllImport("user32.dll")]
		private static extern void mouse_event(int dwFlags, int dx, int dy, int dwData, int dwExtraInfo);

		// Token: 0x0600002F RID: 47
		[DllImport("user32.dll")]
		private static extern ushort GetAsyncKeyState(int vKey);

		// Token: 0x06000030 RID: 48
		[DllImport("user32.dll")]
		private static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, int dwExtraInfo);

		// Token: 0x06000031 RID: 49 RVA: 0x000037F0 File Offset: 0x000019F0
		public static void smethod_0(byte vKeyCode = 34, int sleep = 95)
		{
			GClass2.keybd_event(vKeyCode, 69, 1U, 0);
			Thread.Sleep(sleep);
			GClass2.keybd_event(vKeyCode, 69, 3U, 0);
		}

		// Token: 0x06000032 RID: 50 RVA: 0x0000381C File Offset: 0x00001A1C
		public static void smethod_1(int relx, int rely)
		{
			GClass2.mouse_event(1, relx, rely, 0, 0);
		}

		// Token: 0x06000033 RID: 51 RVA: 0x00003838 File Offset: 0x00001A38
		public static bool smethod_2(Keys key)
		{
			return (GClass2.GetAsyncKeyState((int)key) & 32768) > 0;
		}
	}
}
