﻿using System;
using System.Runtime.CompilerServices;

namespace ns1
{
	// Token: 0x02000005 RID: 5
	internal class Class1
	{
		// Token: 0x17000004 RID: 4
		// (get) Token: 0x06000018 RID: 24 RVA: 0x00002DE8 File Offset: 0x00000FE8
		// (set) Token: 0x06000019 RID: 25 RVA: 0x00002E00 File Offset: 0x00001000
		public string String_0 { get; set; }

		// Token: 0x17000005 RID: 5
		// (get) Token: 0x0600001A RID: 26 RVA: 0x00002E18 File Offset: 0x00001018
		// (set) Token: 0x0600001B RID: 27 RVA: 0x00002E30 File Offset: 0x00001030
		public string String_1 { get; set; }

		// Token: 0x17000006 RID: 6
		// (get) Token: 0x0600001C RID: 28 RVA: 0x00002E48 File Offset: 0x00001048
		// (set) Token: 0x0600001D RID: 29 RVA: 0x00002E60 File Offset: 0x00001060
		public string String_2 { get; set; }

		// Token: 0x0600001E RID: 30 RVA: 0x00002E78 File Offset: 0x00001078
		public override string ToString()
		{
			return string.Concat(new string[]
			{
				this.String_0,
				": ",
				this.String_1,
				": ",
				this.String_2
			});
		}

		// Token: 0x04000005 RID: 5
		[CompilerGenerated]
		private string string_0;

		// Token: 0x04000006 RID: 6
		[CompilerGenerated]
		private string string_1;

		// Token: 0x04000007 RID: 7
		[CompilerGenerated]
		private string string_2;
	}
}
