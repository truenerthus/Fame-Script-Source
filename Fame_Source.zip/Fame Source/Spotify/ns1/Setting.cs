﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using MetroFramework;
using MetroFramework.Controls;

namespace ns1
{
	// Token: 0x0200000B RID: 11
	public partial class Setting : Form
	{
		// Token: 0x06000039 RID: 57
		[DllImport("user32.dll")]
		private static extern bool RegisterHotKey(IntPtr hWnd, int id, int fsModifiers, int vk);

		// Token: 0x0600003A RID: 58
		[DllImport("user32.dll")]
		public static extern bool ReleaseCapture();

		// Token: 0x0600003B RID: 59
		[DllImport("user32.dll")]
		public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

		// Token: 0x0600003C RID: 60 RVA: 0x00003E2C File Offset: 0x0000202C
		public Setting(Thread mainthread, Thread alivethread)
		{
			this.thread_0 = mainthread;
			this.thread_1 = alivethread;
			this.InitializeComponent();
			this.WeaponSelectCombo.DropDownStyle = ComboBoxStyle.DropDownList;
			this.method_1();
		}

		// Token: 0x0600003D RID: 61 RVA: 0x00003E68 File Offset: 0x00002068
		private void ExitButton_Click(object sender, EventArgs e)
		{
			this.thread_1.Abort();
			this.thread_0.Abort();
			base.Close();
		}

		// Token: 0x0600003E RID: 62 RVA: 0x00003EC8 File Offset: 0x000020C8
		private void MinButton_Click(object sender, EventArgs e)
		{
			base.WindowState = FormWindowState.Minimized;
		}

		// Token: 0x0600003F RID: 63 RVA: 0x00003EE0 File Offset: 0x000020E0
		private void ToggleButton_Click(object sender, EventArgs e)
		{
			this.method_0();
		}

		// Token: 0x06000040 RID: 64 RVA: 0x00003EF8 File Offset: 0x000020F8
		private void WeaponSelectCombo_SelectedIndexChanged(object sender, EventArgs e)
		{
			Setting.string_0 = (string)this.WeaponSelectCombo.SelectedItem;
		}

		// Token: 0x06000041 RID: 65 RVA: 0x00003F1C File Offset: 0x0000211C
		private void cmbScope_SelectedIndexChanged(object sender, EventArgs e)
		{
			Setting.string_2 = (string)this.cmbScope.SelectedItem;
		}

		// Token: 0x06000042 RID: 66 RVA: 0x00003F40 File Offset: 0x00002140
		private void cmbAttach_SelectedIndexChanged(object sender, EventArgs e)
		{
			Setting.string_1 = (string)this.cmbAttach.SelectedItem;
		}

		// Token: 0x06000043 RID: 67 RVA: 0x00003F64 File Offset: 0x00002164
		public void method_0()
		{
			Setting.bool_0 = !Setting.bool_0;
			if (Setting.bool_0)
			{
				this.ToggleButton.Text = "Enabled(NUMPAD7)";
				this.ToggleButton.BackColor = Color.Green;
			}
			else if (!Setting.bool_0)
			{
				this.ToggleButton.Text = "Disabled(NUMPAD7)";
				this.ToggleButton.BackColor = Color.FromArgb(255, 75, 75, 75);
			}
		}

		// Token: 0x06000044 RID: 68 RVA: 0x00003FDC File Offset: 0x000021DC
		public void method_1()
		{
			Setting.RegisterHotKey(base.Handle, 0, 0, Keys.NumPad0.GetHashCode());
			Setting.RegisterHotKey(base.Handle, 1, 0, Keys.NumPad1.GetHashCode());
			Setting.RegisterHotKey(base.Handle, 2, 0, Keys.NumPad2.GetHashCode());
			Setting.RegisterHotKey(base.Handle, 3, 0, Keys.NumPad3.GetHashCode());
			Setting.RegisterHotKey(base.Handle, 4, 0, Keys.NumPad4.GetHashCode());
			Setting.RegisterHotKey(base.Handle, 5, 0, Keys.NumPad5.GetHashCode());
			Setting.RegisterHotKey(base.Handle, 6, 0, Keys.NumPad6.GetHashCode());
			Setting.RegisterHotKey(base.Handle, 7, 0, Keys.NumPad7.GetHashCode());
		}

		// Token: 0x06000045 RID: 69 RVA: 0x000040DC File Offset: 0x000022DC
		protected override void WndProc(ref Message m)
		{
			base.WndProc(ref m);
			{
			}
			if (m.Msg == 786)
			{
	
				int num = m.WParam.ToInt32();
				if (num == 1)
				{
					this.WeaponSelectCombo.SelectedIndex = 0;
					Setting.string_0 = (string)this.WeaponSelectCombo.SelectedItem;
				}
				else if (num == 2)
				{
					this.WeaponSelectCombo.SelectedIndex = 1;
					Setting.string_0 = (string)this.WeaponSelectCombo.SelectedItem;
				}
				else if (num == 3)
				{
					this.WeaponSelectCombo.SelectedIndex = 2;
					Setting.string_0 = (string)this.WeaponSelectCombo.SelectedItem;
				}
				else if (num == 4)
				{
					this.WeaponSelectCombo.SelectedIndex = 3;
					Setting.string_0 = (string)this.WeaponSelectCombo.SelectedItem;
				}
				else if (num == 5)
				{
					this.WeaponSelectCombo.SelectedIndex = 4;
					Setting.string_0 = (string)this.WeaponSelectCombo.SelectedItem;
				}
				else if (num == 6)
				{
					this.WeaponSelectCombo.SelectedIndex = 5;
					Setting.string_0 = (string)this.WeaponSelectCombo.SelectedItem;
				}
				else if (num == 7)
				{
					this.method_0();
				}
			}
		}

		// Token: 0x06000046 RID: 70 RVA: 0x00004248 File Offset: 0x00002448
		private void linkbuynow_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			Process.Start("https://rustscripts.com/");
		}

		// Token: 0x06000047 RID: 71 RVA: 0x00004264 File Offset: 0x00002464
		private void trackBar1_Scroll(object sender, EventArgs e)
		{
			Setting.int_5 = this.trackBar1.Value;
		}

		// Token: 0x06000048 RID: 72 RVA: 0x00004284 File Offset: 0x00002484
		private void trackBar_Max_Scroll(object sender, EventArgs e)
		{
			Setting.int_4 = this.trackBar_Max.Value;
		}

		// Token: 0x06000049 RID: 73 RVA: 0x000042A4 File Offset: 0x000024A4
		private void trackBar_Min_Scroll(object sender, EventArgs e)
		{
			Setting.int_3 = this.trackBar_Min.Value;
		}

		// Token: 0x0600004A RID: 74 RVA: 0x000042C4 File Offset: 0x000024C4
		private void numericUpDown_sens_ValueChanged(object sender, EventArgs e)
		{
			Setting.double_0 = Convert.ToDouble(this.numericUpDown_sens.Value);
		}

		// Token: 0x0600004B RID: 75 RVA: 0x000042E8 File Offset: 0x000024E8
		private void checkBox1_CheckedChanged(object sender, EventArgs e)
		{
			if (this.checkBox1.Checked)
			{
				Setting.bool_1 = true;
			}
			else
			{
				Setting.bool_1 = false;
			}
		}

		// Token: 0x0600004C RID: 76 RVA: 0x00004314 File Offset: 0x00002514
		private void method_2(object sender, EventArgs e)
		{
			if (this.metroCheckBox1.Checked)
			{
				Setting.bool_0 = true;
			}
			else
			{
				Setting.bool_0 = false;
			}
		}

		// Token: 0x0600004D RID: 77 RVA: 0x00004340 File Offset: 0x00002540
		private void method_3(object sender, EventArgs e)
		{
			if (this.metroCheckBox2.Checked)
			{
				Setting.bool_1 = true;
			}
			else
			{
				Setting.bool_1 = false;
			}
		}

		// Token: 0x0600004E RID: 78 RVA: 0x0000436C File Offset: 0x0000256C
		private void method_4(object sender, EventArgs e)
		{
			if (this.metroCheckBox3.Checked)
			{
				Setting.bool_2 = true;
			}
			else
			{
				Setting.bool_2 = false;
			}
		}

		// Token: 0x0600004F RID: 79 RVA: 0x00004398 File Offset: 0x00002598
		private void method_5(object sender, ScrollEventArgs e)
		{
			Setting.int_3 = this.metroTrackBar1.Value;
		}

		// Token: 0x06000050 RID: 80 RVA: 0x000043B8 File Offset: 0x000025B8
		private void method_6(object sender, ScrollEventArgs e)
		{
			Setting.int_4 = this.metroTrackBar2.Value;
		}

		// Token: 0x06000051 RID: 81 RVA: 0x000043D8 File Offset: 0x000025D8
		private void method_7(object sender, ScrollEventArgs e)
		{
			Setting.int_5 = this.metroTrackBar3.Value;
		}

		// Token: 0x06000052 RID: 82 RVA: 0x000043F8 File Offset: 0x000025F8
		private void method_8(object sender, EventArgs e)
		{
			Setting.double_0 = Convert.ToDouble(this.numericUpDown1.Value);
		}

		// Token: 0x06000053 RID: 83 RVA: 0x0000441C File Offset: 0x0000261C
		private void method_9(object sender, EventArgs e)
		{
			Setting.int_6 = Convert.ToInt32(this.numericUpDown2.Value);
		}

		// Token: 0x06000054 RID: 84 RVA: 0x00004440 File Offset: 0x00002640
		private void method_10(object sender, EventArgs e)
		{
			Setting.string_0 = (string)this.metroComboBox1.SelectedItem;
		}

		// Token: 0x06000055 RID: 85 RVA: 0x00004464 File Offset: 0x00002664
		private void method_11(object sender, EventArgs e)
		{
			Setting.string_1 = (string)this.metroComboBox2.SelectedItem;
		}

		// Token: 0x06000056 RID: 86 RVA: 0x00004488 File Offset: 0x00002688
		private void method_12(object sender, EventArgs e)
		{
			Setting.string_2 = (string)this.metroComboBox3.SelectedItem;
		}

		// Token: 0x04000025 RID: 37
		private const int int_0 = 132;

		// Token: 0x04000026 RID: 38
		private const int int_1 = 1;

		// Token: 0x04000027 RID: 39
		private const int int_2 = 2;

		// Token: 0x04000028 RID: 40
		public static bool bool_0 = false;

		// Token: 0x04000029 RID: 41
		public static bool bool_1 = false;

		// Token: 0x0400002A RID: 42
		public static bool bool_2 = false;

		// Token: 0x0400002B RID: 43
		public static int int_3 = 1;

		// Token: 0x0400002C RID: 44
		public static int int_4 = 1;

		// Token: 0x0400002D RID: 45
		public static int int_5 = 1;

		// Token: 0x0400002E RID: 46
		public static double double_0 = 0.5;

		// Token: 0x0400002F RID: 47
		public static int int_6 = 90;

		// Token: 0x04000030 RID: 48
		public static string string_0;

		// Token: 0x04000031 RID: 49
		public static string string_1;

		// Token: 0x04000032 RID: 50
		public static string string_2;

		// Token: 0x04000033 RID: 51
		public Thread thread_0;

		// Token: 0x04000034 RID: 52
		public Thread thread_1;

		// Token: 0x0200000C RID: 12
		private enum Enum0
		{
			// Token: 0x0400006C RID: 108
			const_0,
			// Token: 0x0400006D RID: 109
			const_1,
			// Token: 0x0400006E RID: 110
			const_2,
			// Token: 0x0400006F RID: 111
			const_3 = 4,
			// Token: 0x04000070 RID: 112
			const_4 = 8
		}
	}
}
