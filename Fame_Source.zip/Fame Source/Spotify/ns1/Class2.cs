﻿using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using ns2;

namespace ns1
{
	// Token: 0x0200000A RID: 10
	internal static class Class2
	{
		// Token: 0x06000034 RID: 52 RVA: 0x00003858 File Offset: 0x00001A58
		[STAThread]
		private static void Main()
		{
			Mutex mutex = new Mutex(false, "MyUniqueMutexName");
			try
			{
				if (mutex.WaitOne(0, false))
				{
					Application.EnableVisualStyles();
					Application.SetCompatibleTextRenderingDefault(false);
					if (File.Exists("account.info"))
					{
						GClass0.smethod_0();
						string text = GClass4.smethod_0(GClass0.smethod_0());
						string a;
						{
							try
							{
								File.Delete("License.key");
								Thread thread = new Thread(new ThreadStart(Class2.smethod_2));
								thread.Start();
								Thread thread2 = new Thread(new ThreadStart(Class2.smethod_1));
								thread2.Start();
								Application.Run(new Setting(thread, thread2));
								return;
							}
							catch
							{
								MessageBox.Show("Unknown Error(Another device)! Try again!!");
								return;
							}
						}
						try
						{
							Thread thread3 = new Thread(new ThreadStart(Class2.smethod_2));
							thread3.Start();
							Thread thread4 = new Thread(new ThreadStart(Class2.smethod_1));
							thread4.Start();
							Application.Run(new Setting(thread3, thread4));
							return;
						}
						catch
						{
							MessageBox.Show("Unknown Error! Is there Dlls? Try again");
							return;
						}
					}
					if (mutex.WaitOne(0, false))
					{
						Thread thread5 = new Thread(new ThreadStart(Class2.smethod_2));
						thread5.IsBackground = true;
						thread5.Start();
						Thread thread6 = new Thread(new ThreadStart(Class2.smethod_1));
						thread6.IsBackground = true;
						thread6.Start();
						Application.Run(new Setting(thread5, thread6));
					}
				}
				else
				{
					MessageBox.Show("An instance of the application is already running.");
				}
			}
			finally
			{
				if (mutex != null)
				{
					mutex.Close();
					mutex = null;
				}
			}
		}

		// Token: 0x06000036 RID: 54 RVA: 0x00003A78 File Offset: 0x00001C78
		private static void smethod_1()
		{
			
		}

		// Token: 0x06000037 RID: 55 RVA: 0x00003C54 File Offset: 0x00001E54
		private static void smethod_2()
		{
			do
			{
				try
				{
					if (Setting.bool_0 && GClass2.smethod_2(Keys.LButton) && GClass2.smethod_2(Keys.RButton))
					{
						for (int i = 0; i < GClass3.smethod_0().Item1.Length; i++)
						{
							double num = (double)(GClass3.smethod_0().Item1[i, 0] / 2) / Setting.double_0 * GClass3.smethod_1().Item1 * GClass3.smethod_2();
							double num2 = (double)(GClass3.smethod_0().Item1[i, 1] / 2) / Setting.double_0 * GClass3.smethod_1().Item1 * GClass3.smethod_2();
							for (int j = 0; j < Setting.int_5; j++)
							{
								if (GClass2.smethod_2(Keys.LButton) && GClass2.smethod_2(Keys.RButton))
								{
									int num3 = Convert.ToInt32(num / (double)Setting.int_5);
									int num4 = Convert.ToInt32(num2 / (double)Setting.int_5);
									if (Setting.bool_1)
									{
										num3 = GClass3.smethod_3(num3, Setting.int_3, Setting.int_4);
										num4 = GClass3.smethod_3(num4, Setting.int_3, Setting.int_4);
									}
									GClass2.smethod_1(num3, num4);
									Thread.Sleep(Convert.ToInt32((double)(GClass3.smethod_0().Item2 / Setting.int_5) * GClass3.smethod_1().Item2));
								}
							}
							if (Setting.bool_2 && GClass2.smethod_2(Keys.LButton) && GClass2.smethod_2(Keys.RButton))
							{
								int relx = Convert.ToInt32(num % (double)Setting.int_5);
								int rely = Convert.ToInt32(num2 % (double)Setting.int_5);
								GClass2.smethod_1(relx, rely);
							}
						}
					}
				}
				catch
				{
				}
			}
			while (Class2.bool_0);
		}

		// Token: 0x04000022 RID: 34
		public static int int_0 = 10000;

		// Token: 0x04000023 RID: 35
		public static bool bool_0 = true;

		// Token: 0x04000024 RID: 36
		public static int int_1 = 0;
	}
}
