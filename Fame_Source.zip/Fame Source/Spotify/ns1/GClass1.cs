﻿using System;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace ns1
{
	// Token: 0x02000006 RID: 6
	public class GClass1
	{
		// Token: 0x17000007 RID: 7
		// (get) Token: 0x06000020 RID: 32 RVA: 0x00002EC0 File Offset: 0x000010C0
		// (set) Token: 0x06000021 RID: 33 RVA: 0x00002ED8 File Offset: 0x000010D8
		public string String_0 { get; set; }

		// Token: 0x06000022 RID: 34 RVA: 0x00002EF0 File Offset: 0x000010F0
		public GClass1(string host, string p_type, string p_uname, string p_pwd, string p_ver)
		{
			host = host.TrimEnd(new char[]
			{
				'/'
			});
			this.String_0 = host;
			this.string_3 = p_type;
			this.string_1 = p_uname;
			this.string_2 = p_pwd;
			this.string_4 = p_ver;
		}

		// Token: 0x06000023 RID: 35 RVA: 0x00002F6C File Offset: 0x0000116C


		// Token: 0x04000008 RID: 8
		[CompilerGenerated]
		private string string_0;

		// Token: 0x04000009 RID: 9
		public string string_1 = "";

		// Token: 0x0400000A RID: 10
		public string string_2 = "";

		// Token: 0x0400000B RID: 11
		public string string_3 = "";

		// Token: 0x0400000C RID: 12
		public string string_4 = "20200505";
	}
}
