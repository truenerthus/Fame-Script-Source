﻿using System;

namespace ns1
{
	// Token: 0x0200000D RID: 13
	public static class GClass3
	{
		// Token: 0x0600005A RID: 90 RVA: 0x00006F18 File Offset: 0x00005118
		public static ValueTuple<int[,], int> smethod_0()
		{
			return default(ValueTuple<int[,], int>);
		}

		// Token: 0x0600005B RID: 91 RVA: 0x00006F30 File Offset: 0x00005130
		public static ValueTuple<double, double> smethod_1()
		{
			return default(ValueTuple<double, double>);
		}

		// Token: 0x0600005C RID: 92 RVA: 0x00006F48 File Offset: 0x00005148
		public static double smethod_2()
		{
			string string_ = Setting.string_2;
			if (string_ != null)
			{
				if (string_ == "8x Zoom Scope")
				{
					return 3.83721;
				}
				if (string_ == "16x Zoom Scope")
				{
					return 7.65116;
				}
				if (string_ == "Simple Handmade Sight")
				{
					return 0.8;
				}
				if (string_ == "Holosight")
				{
					return 1.18605;
				}
			}
			return 1.0;
		}

		// Token: 0x0600005D RID: 93 RVA: 0x00006FD0 File Offset: 0x000051D0
		public static int smethod_3(int av, int min, int max)
		{
			double num = (double)GClass3.random_0.Next(min, max);
			num /= 100.0;
			return Convert.ToInt32((double)av * num);
		}

		// Token: 0x0600005E RID: 94 RVA: 0x00007004 File Offset: 0x00005204
		// Note: this type is marked as 'beforefieldinit'.
		static GClass3()
		{
			int[,] array = new int[1, 2];
			array[0, 1] = 55;
			GClass3.int_11 = array;
			GClass3.int_12 = 100;
			GClass3.random_0 = new Random();
		}

		// Token: 0x04000071 RID: 113
		private static int[,] int_0 = new int[1, 2];

		// Token: 0x04000072 RID: 114
		public static int[,] int_1 = new int[,]
		{
			{
				-35,
				50
			},
			{
				6,
				46
			},
			{
				-55,
				41
			},
			{
				-42,
				38
			},
			{
				0,
				32
			},
			{
				16,
				29
			},
			{
				28,
				24
			},
			{
				39,
				19
			},
			{
				41,
				14
			},
			{
				41,
				9
			},
			{
				40,
				9
			},
			{
				30,
				20
			},
			{
				17,
				25
			},
			{
				0,
				29
			},
			{
				-15,
				32
			},
			{
				-27,
				33
			},
			{
				-37,
				32
			},
			{
				-43,
				29
			},
			{
				-46,
				24
			},
			{
				-45,
				18
			},
			{
				-42,
				8
			},
			{
				-35,
				5
			},
			{
				-24,
				12
			},
			{
				-11,
				21
			},
			{
				12,
				25
			},
			{
				36,
				28
			},
			{
				49,
				28
			},
			{
				49,
				26
			},
			{
				38,
				21
			}
		};

		// Token: 0x04000073 RID: 115
		public static int int_2 = 133;

		// Token: 0x04000074 RID: 116
		public static int[,] int_3 = new int[,]
		{
			{
				-2,
				26
			},
			{
				-6,
				29
			},
			{
				-10,
				33
			},
			{
				-14,
				31
			},
			{
				-15,
				25
			},
			{
				-14,
				20
			},
			{
				-9,
				15
			},
			{
				-2,
				15
			},
			{
				9,
				12
			},
			{
				17,
				10
			},
			{
				20,
				8
			},
			{
				17,
				7
			},
			{
				10,
				5
			},
			{
				0,
				4
			},
			{
				-5,
				4
			},
			{
				-9,
				4
			},
			{
				-12,
				3
			},
			{
				-14,
				3
			},
			{
				-15,
				3
			},
			{
				-15,
				2
			},
			{
				-14,
				2
			},
			{
				-13,
				2
			},
			{
				-10,
				2
			},
			{
				-7,
				2
			},
			{
				-3,
				2
			},
			{
				13,
				2
			},
			{
				30,
				2
			},
			{
				36,
				3
			},
			{
				30,
				3
			}
		};

		// Token: 0x04000075 RID: 117
		public static int int_4 = 120;

		// Token: 0x04000076 RID: 118
		public static int[,] int_5 = new int[,]
		{
			{
				-15,
				32
			},
			{
				-5,
				32
			},
			{
				3,
				31
			},
			{
				11,
				29
			},
			{
				13,
				26
			},
			{
				10,
				23
			},
			{
				2,
				18
			},
			{
				-7,
				16
			},
			{
				-13,
				14
			},
			{
				-13,
				13
			},
			{
				-7,
				11
			},
			{
				2,
				10
			},
			{
				10,
				9
			},
			{
				12,
				8
			},
			{
				11,
				7
			},
			{
				5,
				7
			},
			{
				-2,
				6
			},
			{
				-6,
				6
			},
			{
				-7,
				6
			}
		};

		// Token: 0x04000077 RID: 119
		public static int int_6 = 130;

		// Token: 0x04000078 RID: 120
		public static int[,] int_7 = new int[,]
		{
			{
				0,
				22
			},
			{
				0,
				31
			},
			{
				0,
				34
			},
			{
				13,
				36
			},
			{
				31,
				31
			},
			{
				34,
				23
			},
			{
				24,
				14
			},
			{
				1,
				11
			},
			{
				-19,
				10
			},
			{
				-26,
				9
			},
			{
				-21,
				8
			},
			{
				-4,
				7
			},
			{
				8,
				6
			},
			{
				14,
				5
			},
			{
				18,
				4
			},
			{
				17,
				2
			},
			{
				13,
				3
			},
			{
				6,
				2
			},
			{
				-1,
				1
			},
			{
				-5,
				1
			},
			{
				-9,
				1
			},
			{
				-11,
				0
			},
			{
				-13,
				0
			},
			{
				-13,
				0
			},
			{
				-14,
				0
			},
			{
				-13,
				0
			},
			{
				-11,
				0
			},
			{
				-9,
				0
			},
			{
				-6,
				0
			}
		};

		// Token: 0x04000079 RID: 121
		public static int int_8 = 100;

		// Token: 0x0400007A RID: 122
		public static int[,] int_9 = new int[,]
		{
			{
				-13,
				27
			},
			{
				-6,
				27
			},
			{
				0,
				25
			},
			{
				6,
				25
			},
			{
				10,
				23
			},
			{
				11,
				21
			},
			{
				9,
				18
			},
			{
				4,
				16
			},
			{
				-3,
				14
			},
			{
				-9,
				13
			},
			{
				-11,
				12
			},
			{
				-10,
				10
			},
			{
				-6,
				9
			},
			{
				0,
				10
			},
			{
				6,
				8
			},
			{
				9,
				7
			},
			{
				10,
				6
			},
			{
				9,
				6
			},
			{
				4,
				5
			},
			{
				0,
				5
			},
			{
				-4,
				5
			},
			{
				-6,
				5
			},
			{
				-5,
				5
			}
		};

		// Token: 0x0400007B RID: 123
		public static int int_10 = 100;

		// Token: 0x0400007C RID: 124
		public static int[,] int_11;

		// Token: 0x0400007D RID: 125
		public static int int_12;

		// Token: 0x0400007E RID: 126
		private static Random random_0;
	}
}
