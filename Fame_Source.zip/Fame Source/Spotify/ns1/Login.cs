﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ns1
{
	// Token: 0x02000008 RID: 8
	public partial class Login : Form
	{
		// Token: 0x06000026 RID: 38 RVA: 0x00002FC4 File Offset: 0x000011C4
		public Login()
		{
			this.InitializeComponent();
		}

        private void btnok_Click(object sender, EventArgs e)
        {
			
        }
    }
}
