﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using ns3;

namespace ns6
{
	// Token: 0x02000019 RID: 25
	public partial class UnhandledExceptionForm : Form
	{
		// Token: 0x0600008C RID: 140 RVA: 0x000025E8 File Offset: 0x000007E8
		public UnhandledExceptionForm()
		{
			this.method_0();
		}

		// Token: 0x0600008D RID: 141 RVA: 0x000025F6 File Offset: 0x000007F6
		private void method_0()
		{
			this.method_0();
		}

		// Token: 0x0600008E RID: 142 RVA: 0x00007DA8 File Offset: 0x00005FA8
		public UnhandledExceptionForm(Exception e)
		{
			this.InitializeComponent();
			this.appIcon.Image = Icon.ExtractAssociatedIcon(Application.ExecutablePath).ToBitmap();
			base.Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
			this.exception_0 = e;
			this.headerLbl.Text = string.Format(this.headerLbl.Text, GClass5.smethod_4());
			this.firstLineLbl.Text = string.Format(this.firstLineLbl.Text, GClass5.smethod_3());
			this.secondLineLbl.Text = string.Format(this.secondLineLbl.Text, GClass5.smethod_4());
		}

		// Token: 0x0600008F RID: 143 RVA: 0x00007E54 File Offset: 0x00006054
		private void sendErrorReportBtn_Click(object sender, EventArgs e)
		{
			this.timer_0 = new System.Windows.Forms.Timer();
			this.timer_0.Interval = 150;
			this.timer_0.Tick += this.timer_0_Tick;
			this.timer_0.Start();
			this.sendReportLbl.Visible = true;
			this.sendReportLbl.Text = "Sending error report...";
			this.backgroundWorker_0.RunWorkerAsync();
		}

		// Token: 0x06000090 RID: 144 RVA: 0x000025FE File Offset: 0x000007FE
		private void closeBtn_Click(object sender, EventArgs e)
		{
			Environment.Exit(1);
		}

		// Token: 0x06000091 RID: 145 RVA: 0x00002606 File Offset: 0x00000806
		private void timer_0_Tick(object sender, EventArgs e)
		{
			this.sendReportPic.Visible = !this.sendReportPic.Visible;
		}

		// Token: 0x06000092 RID: 146 RVA: 0x00002621 File Offset: 0x00000821
		private void backgroundWorker_0_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
		{
			if (this.timer_0 != null)
			{
				this.timer_0.Stop();
				this.timer_0 = null;
			}
			this.sendReportLbl.Text = "Error report sent successfully";
			this.sendReportPic.Visible = true;
		}

		// Token: 0x06000093 RID: 147 RVA: 0x00002659 File Offset: 0x00000859
		private void backgroundWorker_0_DoWork(object sender, DoWorkEventArgs e)
		{
			new GClass5(this.exception_0).method_0();
		}

		// Token: 0x06000094 RID: 148 RVA: 0x0000266B File Offset: 0x0000086B
		[Obfuscation]
		public static void r()
		{
			AppDomain.CurrentDomain.UnhandledException += UnhandledExceptionForm.smethod_1;
			Application.ThreadException += UnhandledExceptionForm.smethod_0;
		}

		// Token: 0x06000095 RID: 149 RVA: 0x00002694 File Offset: 0x00000894
		private static void smethod_0(object sender, ThreadExceptionEventArgs e)
		{
			UnhandledExceptionForm.smethod_2(e.Exception);
		}

		// Token: 0x06000096 RID: 150 RVA: 0x000026A1 File Offset: 0x000008A1
		private static void smethod_1(object sender, UnhandledExceptionEventArgs e)
		{
			UnhandledExceptionForm.smethod_2(e.ExceptionObject as Exception);
		}

		// Token: 0x06000097 RID: 151 RVA: 0x000026B3 File Offset: 0x000008B3
		private static void smethod_2(Exception e)
		{
			if (e == null)
			{
				return;
			}
			if (Environment.UserInteractive)
			{
				new UnhandledExceptionForm(e).ShowDialog();
			}
		}

		// Token: 0x04000093 RID: 147
		private System.Windows.Forms.Timer timer_0;

		// Token: 0x04000094 RID: 148
		private Exception exception_0;
	}
}
