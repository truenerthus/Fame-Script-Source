﻿namespace ns6
{
	// Token: 0x02000019 RID: 25
	public partial class UnhandledExceptionForm : global::System.Windows.Forms.Form
	{
		// Token: 0x06000098 RID: 152 RVA: 0x000026CC File Offset: 0x000008CC
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.icontainer_0 != null)
			{
				this.icontainer_0.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000099 RID: 153 RVA: 0x00007EC8 File Offset: 0x000060C8
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::ns6.UnhandledExceptionForm));
			this.headerLbl = new global::System.Windows.Forms.Label();
			this.panel1 = new global::System.Windows.Forms.Panel();
			this.appIcon = new global::System.Windows.Forms.PictureBox();
			this.firstLineLbl = new global::System.Windows.Forms.Label();
			this.secondLineLbl = new global::System.Windows.Forms.Label();
			this.sendErrorReportBtn = new global::System.Windows.Forms.Button();
			this.closeBtn = new global::System.Windows.Forms.Button();
			this.linkLabel1 = new global::System.Windows.Forms.LinkLabel();
			this.backgroundWorker_0 = new global::System.ComponentModel.BackgroundWorker();
			this.sendReportPic = new global::System.Windows.Forms.PictureBox();
			this.sendReportLbl = new global::System.Windows.Forms.Label();
			this.panel1.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.appIcon).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.sendReportPic).BeginInit();
			base.SuspendLayout();
			this.headerLbl.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 177);
			this.headerLbl.Location = new global::System.Drawing.Point(14, 10);
			this.headerLbl.Name = "headerLbl";
			this.headerLbl.Size = new global::System.Drawing.Size(381, 37);
			this.headerLbl.TabIndex = 0;
			this.headerLbl.Text = "{0} has encountered a problem. We are sorry for the inconvenience.";
			this.panel1.BackColor = global::System.Drawing.Color.White;
			this.panel1.Controls.Add(this.appIcon);
			this.panel1.Controls.Add(this.headerLbl);
			this.panel1.Dock = global::System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new global::System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new global::System.Drawing.Size(477, 58);
			this.panel1.TabIndex = 2;
			this.appIcon.Location = new global::System.Drawing.Point(413, 3);
			this.appIcon.Name = "appIcon";
			this.appIcon.Size = new global::System.Drawing.Size(54, 50);
			this.appIcon.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.appIcon.TabIndex = 1;
			this.appIcon.TabStop = false;
			this.firstLineLbl.AutoSize = true;
			this.firstLineLbl.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 177);
			this.firstLineLbl.Location = new global::System.Drawing.Point(24, 78);
			this.firstLineLbl.Name = "firstLineLbl";
			this.firstLineLbl.Size = new global::System.Drawing.Size(199, 13);
			this.firstLineLbl.TabIndex = 3;
			this.firstLineLbl.Text = "Please tell {0} about this problem.";
			this.secondLineLbl.Location = new global::System.Drawing.Point(24, 102);
			this.secondLineLbl.Name = "secondLineLbl";
			this.secondLineLbl.Size = new global::System.Drawing.Size(397, 36);
			this.secondLineLbl.TabIndex = 4;
			this.secondLineLbl.Text = "We have created an error report that you can send to help us improve {0}. We will treat this report as confidential and anonymous.";
			this.sendErrorReportBtn.Location = new global::System.Drawing.Point(280, 204);
			this.sendErrorReportBtn.Name = "sendErrorReportBtn";
			this.sendErrorReportBtn.Size = new global::System.Drawing.Size(106, 26);
			this.sendErrorReportBtn.TabIndex = 5;
			this.sendErrorReportBtn.Text = "&Send Error Report";
			this.sendErrorReportBtn.UseVisualStyleBackColor = true;
			this.sendErrorReportBtn.Click += new global::System.EventHandler(this.sendErrorReportBtn_Click);
			this.closeBtn.Location = new global::System.Drawing.Point(392, 204);
			this.closeBtn.Name = "closeBtn";
			this.closeBtn.Size = new global::System.Drawing.Size(75, 26);
			this.closeBtn.TabIndex = 6;
			this.closeBtn.Text = "&Close";
			this.closeBtn.UseVisualStyleBackColor = true;
			this.closeBtn.Click += new global::System.EventHandler(this.closeBtn_Click);
			this.linkLabel1.AutoSize = true;
			this.linkLabel1.Location = new global::System.Drawing.Point(23, 204);
			this.linkLabel1.Name = "linkLabel1";
			this.linkLabel1.Size = new global::System.Drawing.Size(200, 13);
			this.linkLabel1.TabIndex = 7;
			this.linkLabel1.TabStop = true;
			this.linkLabel1.Text = "What data does this error report contain?";
			this.linkLabel1.Visible = false;
			this.backgroundWorker_0.DoWork += new global::System.ComponentModel.DoWorkEventHandler(this.backgroundWorker_0_DoWork);
			this.backgroundWorker_0.RunWorkerCompleted += new global::System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorker_0_RunWorkerCompleted);
			this.sendReportPic.Location = new global::System.Drawing.Point(27, 160);
			this.sendReportPic.Name = "sendReportPic";
			this.sendReportPic.Size = new global::System.Drawing.Size(20, 20);
			this.sendReportPic.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.sendReportPic.TabIndex = 8;
			this.sendReportPic.TabStop = false;
			this.sendReportPic.Visible = false;
			this.sendReportLbl.AutoSize = true;
			this.sendReportLbl.Location = new global::System.Drawing.Point(53, 163);
			this.sendReportLbl.Name = "sendReportLbl";
			this.sendReportLbl.Size = new global::System.Drawing.Size(109, 13);
			this.sendReportLbl.TabIndex = 9;
			this.sendReportLbl.Text = "Sending error report...";
			this.sendReportLbl.Visible = false;
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(477, 239);
			base.Controls.Add(this.sendReportLbl);
			base.Controls.Add(this.sendReportPic);
			base.Controls.Add(this.linkLabel1);
			base.Controls.Add(this.closeBtn);
			base.Controls.Add(this.sendErrorReportBtn);
			base.Controls.Add(this.secondLineLbl);
			base.Controls.Add(this.firstLineLbl);
			base.Controls.Add(this.panel1);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedSingle;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "UnhandledExceptionForm";
			base.ShowInTaskbar = false;
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "UnhandledExceptionForm";
			this.panel1.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.appIcon).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.sendReportPic).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000095 RID: 149
		private global::System.ComponentModel.IContainer icontainer_0;

		// Token: 0x04000096 RID: 150
		private global::System.Windows.Forms.Label headerLbl;

		// Token: 0x04000097 RID: 151
		private global::System.Windows.Forms.Panel panel1;

		// Token: 0x04000098 RID: 152
		private global::System.Windows.Forms.PictureBox appIcon;

		// Token: 0x04000099 RID: 153
		private global::System.Windows.Forms.Label firstLineLbl;

		// Token: 0x0400009A RID: 154
		private global::System.Windows.Forms.Label secondLineLbl;

		// Token: 0x0400009B RID: 155
		private global::System.Windows.Forms.Button sendErrorReportBtn;

		// Token: 0x0400009C RID: 156
		private global::System.Windows.Forms.Button closeBtn;

		// Token: 0x0400009D RID: 157
		private global::System.Windows.Forms.LinkLabel linkLabel1;

		// Token: 0x0400009E RID: 158
		private global::System.ComponentModel.BackgroundWorker backgroundWorker_0;

		// Token: 0x0400009F RID: 159
		private global::System.Windows.Forms.PictureBox sendReportPic;

		// Token: 0x040000A0 RID: 160
		private global::System.Windows.Forms.Label sendReportLbl;
	}
}
