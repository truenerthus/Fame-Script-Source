﻿using System;

// Token: 0x0200001A RID: 26
// (Invoke) Token: 0x0600009D RID: 157
internal delegate void ExitDelegate();
