﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace ns0
{
	// Token: 0x02000002 RID: 2
	[CompilerGenerated]
	[DebuggerNonUserCode]
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
	internal class Class0
	{
		// Token: 0x06000002 RID: 2 RVA: 0x0000245F File Offset: 0x0000065F
		internal Class0()
		{
		}

		// Token: 0x17000001 RID: 1
		// (get) Token: 0x06000003 RID: 3 RVA: 0x000026EC File Offset: 0x000008EC
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager_0
		{
			get
			{
				if (Class0.resourceManager_0 == null)
				{
					Class0.resourceManager_0 = new ResourceManager("ns0.Class0", typeof(Class0).Assembly);
				}
				return Class0.resourceManager_0;
			}
		}

		// Token: 0x17000002 RID: 2
		// (get) Token: 0x06000004 RID: 4 RVA: 0x00002728 File Offset: 0x00000928
		// (set) Token: 0x06000005 RID: 5 RVA: 0x00002740 File Offset: 0x00000940
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo CultureInfo_0
		{
			get
			{
				return Class0.cultureInfo_0;
			}
			set
			{
				Class0.cultureInfo_0 = value;
			}
		}

		// Token: 0x04000001 RID: 1
		private static ResourceManager resourceManager_0;

		// Token: 0x04000002 RID: 2
		private static CultureInfo cultureInfo_0;
	}
}
