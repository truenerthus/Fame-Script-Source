﻿using System;
using System.CodeDom.Compiler;
using System.Configuration;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace ns5
{
	// Token: 0x02000017 RID: 23
	internal sealed partial class Class4 : ApplicationSettingsBase
	{
		// Token: 0x1700000B RID: 11
		// (get) Token: 0x06000088 RID: 136 RVA: 0x000025B8 File Offset: 0x000007B8
		[DebuggerNonUserCode]
		[DefaultSettingValue("http://secureteam.net/ErrorReporting.asmx")]
		[SpecialSetting(SpecialSetting.WebServiceUrl)]
		[ApplicationScopedSetting]
		public string String_0
		{
			get
			{
				return (string)this["AgileDotNet_ExceptionReporting_SecureTeamWs_ErrorReporting"];
			}
		}
	}
}
