﻿using System;
using System.CodeDom.Compiler;
using System.Configuration;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace ns5
{
	// Token: 0x02000017 RID: 23
	[CompilerGenerated]
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "10.0.0.0")]
	internal sealed partial class Class4 : ApplicationSettingsBase
	{
		// Token: 0x1700000A RID: 10
		// (get) Token: 0x06000087 RID: 135 RVA: 0x000025B1 File Offset: 0x000007B1
		public static Class4 Class4_0
		{
			get
			{
				return Class4.class4_0;
			}
		}

		// Token: 0x04000091 RID: 145
		private static Class4 class4_0 = (Class4)SettingsBase.Synchronized(new Class4());
	}
}
