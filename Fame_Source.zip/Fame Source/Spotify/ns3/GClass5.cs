﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using ns4;

namespace ns3
{
	// Token: 0x02000014 RID: 20
	public class GClass5
	{
		// Token: 0x06000065 RID: 101 RVA: 0x00002479 File Offset: 0x00000679
		public GClass5(Exception exception)
		{
			this.exception_0 = exception;
		}

		// Token: 0x06000066 RID: 102 RVA: 0x000072C8 File Offset: 0x000054C8
		static GClass5()
		{
			GClass5.string_0 = GClass5.smethod_0(typeof(GClass5).Assembly).ToString();
			GClass5.string_1 = ((AssemblyCompanyAttribute)typeof(GClass5).Assembly.GetCustomAttributes(typeof(AssemblyCompanyAttribute), true)[0]).Company;
			GClass5.string_2 = ((AssemblyProductAttribute)typeof(GClass5).Assembly.GetCustomAttributes(typeof(AssemblyProductAttribute), true)[0]).Product;
		}

		// Token: 0x06000067 RID: 103 RVA: 0x00002488 File Offset: 0x00000688
		private static Version smethod_0(Assembly assembly)
		{
			return new AssemblyName(assembly.FullName).Version;
		}

		// Token: 0x06000068 RID: 104 RVA: 0x00007360 File Offset: 0x00005560
		public void method_0()
		{
			try
			{
				MemoryStream memoryStream = GClass5.smethod_1(this.exception_0, true);
				memoryStream.Position = 0L;
				new StreamReader(memoryStream).ReadToEnd();
			}
			catch (Exception e)
			{
				try
				{
					MemoryStream memoryStream2 = GClass5.smethod_1(e, false);
					memoryStream2.Position = 0L;
					new StreamReader(memoryStream2).ReadToEnd();
				}
				catch
				{
				}
			}
		}

		// Token: 0x06000069 RID: 105 RVA: 0x0000249A File Offset: 0x0000069A
		private void method_1(string xml)
		{
			new GClass6().method_0(xml);
		}

		// Token: 0x0600006A RID: 106 RVA: 0x000073DC File Offset: 0x000055DC
		private static MemoryStream smethod_1(Exception e, bool useAgileDotNetStackFrames)
		{
			XmlWriterSettings xmlWriterSettings = new XmlWriterSettings();
			xmlWriterSettings.Indent = true;
			xmlWriterSettings.Encoding = Encoding.UTF8;
			MemoryStream memoryStream = new MemoryStream();
			using (XmlWriter xmlWriter = XmlWriter.Create(memoryStream, xmlWriterSettings))
			{
				xmlWriter.WriteStartDocument();
				xmlWriter.WriteStartElement("ErrorReportData");
				xmlWriter.WriteAttributeString("Version", "5.3.0.0");
				xmlWriter.WriteAttributeString("CompanyId", GClass5.smethod_2());
				xmlWriter.WriteAttributeString("CompanyName", GClass5.smethod_3());
				xmlWriter.WriteAttributeString("Type", e.GetType().AssemblyQualifiedName);
				xmlWriter.WriteAttributeString("Description", useAgileDotNetStackFrames ? e.Message : e.ToString());
				xmlWriter.WriteAttributeString("ProductName", GClass5.smethod_4());
				xmlWriter.WriteAttributeString("Release", GClass5.smethod_5());
				xmlWriter.WriteAttributeString("OS", Environment.OSVersion.VersionString);
				if (e.StackTrace != null && useAgileDotNetStackFrames)
				{
					GClass5.smethod_6(xmlWriter, e);
				}
				xmlWriter.WriteEndElement();
				xmlWriter.WriteEndDocument();
			}
			return memoryStream;
		}

		// Token: 0x0600006B RID: 107 RVA: 0x000024A7 File Offset: 0x000006A7
		public static string smethod_2()
		{
			return "9GFC7Tqg14g=";
		}

		// Token: 0x0600006C RID: 108 RVA: 0x000024AE File Offset: 0x000006AE
		public static string smethod_3()
		{
			return "SecureTeam Software Ltd.";
		}

		// Token: 0x0600006D RID: 109 RVA: 0x000024B5 File Offset: 0x000006B5
		public static string smethod_4()
		{
			return "Fame";
		}

		// Token: 0x0600006E RID: 110 RVA: 0x000024BC File Offset: 0x000006BC
		public static string smethod_5()
		{
			return "2.2";
		}

		// Token: 0x0600006F RID: 111 RVA: 0x000074F4 File Offset: 0x000056F4
		private static void smethod_6(XmlWriter xw, Exception e)
		{
			xw.WriteStartElement("StackFrames");
			List<StackFrame> list = (List<StackFrame>)e.Data["StackFrames"];
			Dictionary<StackFrame, object[]> dictionary = (Dictionary<StackFrame, object[]>)e.Data["AgileDotNetStackFrames"];
			string[] array = e.StackTrace.Split(new char[]
			{
				'\r',
				'\n'
			}, StringSplitOptions.RemoveEmptyEntries);
			if (list != null && list.Count > 0)
			{
				MethodBase method = list[0].GetMethod();
				string value = method.DeclaringType.FullName + "." + method.Name;
				int num = 0;
				while (num < array.Length && !array[num].Contains(value))
				{
					GClass5.smethod_7(xw, array[num]);
					num++;
				}
				using (List<StackFrame>.Enumerator enumerator = list.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						StackFrame stackFrame = enumerator.Current;
						xw.WriteStartElement("StackFrame");
						MethodBase method2 = stackFrame.GetMethod();
						string value2 = GClass5.smethod_11(method2);
						xw.WriteAttributeString("Text", value2);
						if (dictionary.ContainsKey(stackFrame))
						{
							object[] args = dictionary[stackFrame];
							string value3 = GClass5.smethod_8(method2, args);
							xw.WriteAttributeString("Args", value3);
						}
						xw.WriteEndElement();
					}
					goto IL_167;
				}
			}
			foreach (string line in array)
			{
				GClass5.smethod_7(xw, line);
			}
			IL_167:
			xw.WriteEndElement();
		}

		// Token: 0x06000070 RID: 112 RVA: 0x00007680 File Offset: 0x00005880
		internal static void smethod_7(XmlWriter xw, string line)
		{
			xw.WriteStartElement("StackFrame");
			Match match = new Regex("(?<name>[\\w|\\.|=|`|<|>]+)(?=\\()(?<mparams>\\(.*\\))").Match(line);
			Group group = match.Groups["mparams"];
			Group group2 = match.Groups["name"];
			int num = group2.Value.LastIndexOf('.');
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append(group2.Value.Substring(0, num));
			stringBuilder.Append(" ");
			stringBuilder.Append(group2.Value.Substring(num + 1));
			stringBuilder.Append(group.Value);
			stringBuilder.Append(";");
			xw.WriteAttributeString("Text", stringBuilder.ToString());
			xw.WriteEndElement();
		}

		// Token: 0x06000071 RID: 113 RVA: 0x00007744 File Offset: 0x00005944
		private static string smethod_8(MethodBase mb, object[] args)
		{
			bool isStatic = mb.IsStatic;
			MemoryStream memoryStream = new MemoryStream();
			BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
			binaryWriter.Write(args.Length);
			for (int i = 0; i < args.Length; i++)
			{
				string paramName;
				Type type;
				if (!isStatic && i == 0)
				{
					paramName = "this";
					type = mb.DeclaringType;
				}
				else
				{
					ParameterInfo parameterInfo = mb.GetParameters()[i - (isStatic ? 0 : 1)];
					paramName = parameterInfo.Name;
					type = parameterInfo.ParameterType;
				}
				GClass5.smethod_9(binaryWriter, type, paramName, args[i], 0);
			}
			return Convert.ToBase64String(memoryStream.ToArray());
		}

		// Token: 0x06000072 RID: 114 RVA: 0x000077D0 File Offset: 0x000059D0
		internal static void smethod_9(BinaryWriter bw, Type type, string paramName, object o, int depth)
		{
			
		}

		// Token: 0x06000073 RID: 115 RVA: 0x00007A54 File Offset: 0x00005C54
		private static string smethod_10(Type type)
		{
			string result = "Unknown type name";
			if ((type.IsGenericType || type.IsGenericParameter) && !string.IsNullOrEmpty(type.Name))
			{
				if (string.IsNullOrEmpty(type.Namespace))
				{
					result = type.Name;
				}
				else
				{
					result = string.Format("{0}.{1}", type.Namespace, type.Name);
				}
			}
			else if (type.FullName != null)
			{
				result = type.FullName;
			}
			return result;
		}

		// Token: 0x06000074 RID: 116 RVA: 0x00007AC4 File Offset: 0x00005CC4
		private static string smethod_11(MethodBase mb)
		{
			string value = GClass5.smethod_12(mb.DeclaringType.Assembly);
			string fullName = mb.DeclaringType.FullName;
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append(value);
			stringBuilder.Append("!");
			stringBuilder.Append(fullName);
			stringBuilder.Append(" ");
			if (mb.IsFamilyAndAssembly)
			{
				stringBuilder.Append("protected internal");
			}
			else if (mb.IsPrivate)
			{
				stringBuilder.Append("private");
			}
			else if (mb.IsPublic)
			{
				stringBuilder.Append("public");
			}
			else if (mb.IsFamily)
			{
				stringBuilder.Append("protected");
			}
			else if (mb.IsAssembly)
			{
				stringBuilder.Append("internal");
			}
			stringBuilder.Append(" ");
			if (mb.IsStatic)
			{
				stringBuilder.Append("static");
			}
			else if (mb.IsVirtual)
			{
				stringBuilder.Append("virtual");
			}
			if (!mb.IsConstructor)
			{
				stringBuilder.Append(" ");
				stringBuilder.Append(((MethodInfo)mb).ReturnType.Name);
				stringBuilder.Append(" ");
			}
			stringBuilder.Append(mb.Name);
			stringBuilder.Append("(");
			ParameterInfo[] parameters = mb.GetParameters();
			for (int i = 0; i < parameters.Length; i++)
			{
				stringBuilder.Append(parameters[i].ParameterType.Name);
				stringBuilder.Append(" ");
				stringBuilder.Append(parameters[i].Name);
				if (i != parameters.Length - 1)
				{
					stringBuilder.Append(", ");
				}
			}
			stringBuilder.Append(");");
			return stringBuilder.ToString();
		}

		// Token: 0x06000075 RID: 117 RVA: 0x00007C80 File Offset: 0x00005E80
		private static string smethod_12(Assembly asm)
		{
			string text = asm.FullName;
			int num = text.IndexOf(',');
			if (num >= 0)
			{
				text = text.Substring(0, num);
			}
			return text;
		}

		// Token: 0x04000089 RID: 137
		private static string string_0;

		// Token: 0x0400008A RID: 138
		private static string string_1;

		// Token: 0x0400008B RID: 139
		private static string string_2;

		// Token: 0x0400008C RID: 140
		private static string string_3 = "UnknownCompanyId";

		// Token: 0x0400008D RID: 141
		private Exception exception_0;
	}
}
