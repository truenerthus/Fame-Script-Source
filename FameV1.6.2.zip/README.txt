  ______                      _____           _       _         __   ___  
 |  ____|                    / ____|         (_)     | |       /_ | / _ \ 
 | |__ __ _ _ __ ___   ___  | (___   ___ _ __ _ _ __ | |_ ___   | || | | |
 |  __/ _` | '_ ` _ \ / _ \  \___ \ / __| '__| | '_ \| __/ __|  | || | | |
 | | | (_| | | | | | |  __/  ____) | (__| |  | | |_) | |_\__ \  | || |_| |
 |_|  \__,_|_| |_| |_|\___| |_____/ \___|_|  |_| .__/ \__|___/  |_(_)___/ 
                                               | |                        
CONTENTS:

1. Contact
2. Instructions
3. Troubleshooting

----------------------------------------------------------------------------
 
Discord: Fame#7614 Email: Famescripts@gmail.com Website: www.rustscripts.com

If anything ever happens to my discord (If it gets banned or hacked) you 
will find up-to-date contact information on our website.

----------------------------------------------------------------------------

1.0 SETUP INSTRUCTIONS:

1. Unzip this file into a folder of your choice. Every file present in this
   .zip file must be in this folder. You must not remove / delete any files.

2. Make sure all antiviruses are turned off, or you have relevant exclusions
   set up for the program.

3. Make sure you are on Windows 10 version 2004, or Windows 10 version 20H2.
   You can do this by typing "winver" without the " in your windows search
   bar, and clicking the command that comes up. If your windows version is
   not 2004 or 20H2, please update to these versions.

4. Make sure your VC_Redist is up to date.

5. Run Discord.exe as administrator

6. Click Register and fill out the register field with your Registration code sent
   in the email when you buy..

7. Log in using the credentials your registered

8. Enjoy!

----------------------------------------------------------------------------

1.0 TROUBLESHOOTING

Q. Program is not running / program deletes itself!
A. Disable your antivirus / add an exclusion.

Q. I am getting an error when trying to register an account!
A. First, make sure there are no spaces " " present in any field.
   Then make sure that your internet is up and working. If you
   are using Ethernet, switch to WiFi or disable IPV6. If none
   of these actions work, open a ticket and contact Fame.

Q. The program is running fine, and I have registered and logged in, however
   it is not affecting the recoil at all!
A. in your windows searchbar, type "winver" without the ", and then click the
   command it runs. If your version is not 2004 or 20H2, upgrade to either of
   those versions. If it is one of those versions, make sure your VC_Redist is
   up to date, and you have no antiviruses that could be interfering. 

Q. I am getting the error "Code Check Failed"
A. Add an inbound and outbound firewall exclusion for the program

This section will be expanded as more bugs come in!



